let gulp = require('gulp'),
    /**
     * Auto-loader for plugins
     *
     * @property connectPhp gulp-connect-php
     * @property newer gulp-newer
     * @property sass gulp-sass
     * @property sequence gulp-sequence
     * @property sourcemaps gulp-sourcemaps
     */
    $ = require('gulp-load-plugins')();

gulp.task('watcher',
    $.sequence([ 'html:transfer-vendor', 'css:local-preprocess', 'css:local-transfer' ],
        [ 'watcher:dev', 'launch-server' ]));

gulp.task('watcher:dev', () => {
    gulp.watch('html/assets/scss/**/*.scss', [ 'css:local-preprocess' ]);
    gulp.watch('html/assets/includeCss/**/*.css', [ 'css:local-transfer' ]);
    gulp.watch('vendor/**/*', [ 'html:transfer-vendor' ]);
});
gulp.task('watcher:dev-css', () => {
    gulp.watch('html/assets/scss/**/*.scss', [ 'css:local-preprocess' ]);
    gulp.watch('html/assets/includeCss/**/*.css', [ 'css:local-transfer' ]);
});

gulp.task('html:transfer-vendor', () => {
    return gulp.src('vendor/**/*')
        .pipe($.newer('application/vendor/'))
        .pipe(gulp.dest('application/vendor/'));
});
gulp.task('css:local-transfer', () => {
    // adds transferred css to source (for local hosting)
    return gulp.src('html/assets/includeCss/**/*.css')
        .pipe($.newer('html/assets/stylesheets/'))
        .pipe(gulp.dest('html/assets/stylesheets/'));
});
gulp.task('css:local-preprocess', () => {
    // adds preprocessed css to source (for local hosting)
    return gulp.src('html/assets/scss/**/*.scss')
        .pipe($.newer({
            dest: 'html/assets/stylesheets/',
            ext: '.css',
            extra: [ 'html/assets/scss/**/_*.scss' ]
        }))
        .pipe($.sourcemaps.init())
        .pipe($.sass({
            includePaths: [
                'foundation-sites/scss',
                'node_modules/motion-ui/src'
            ],
            precision: 8
        }).on('error', $.sass.logError))
        .pipe($.sourcemaps.write('.'))
        .pipe(gulp.dest('html/assets/stylesheets/'));
});
gulp.task('launch-server', function () {
    $.connectPhp.server({
        base: 'html',
        hostname: '127.0.0.1',
        open: true
    });
});