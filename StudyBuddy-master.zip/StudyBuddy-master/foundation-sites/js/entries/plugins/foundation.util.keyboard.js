import { Foundation } from './foundation.core';
import { Keyboard } from '../../foundation.util.keyboard';

Foundation.Keyboard = Keyboard;
