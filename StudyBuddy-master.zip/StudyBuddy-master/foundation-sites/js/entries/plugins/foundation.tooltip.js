import { Foundation } from './foundation.core';

import { Tooltip } from '../../foundation.tooltip';
Foundation.plugin(Tooltip, 'Tooltip');
