import { Foundation } from './foundation.core';

import { Equalizer } from '../../foundation.equalizer';
Foundation.plugin(Equalizer, 'Equalizer');
