/** @var {gsap.CSSRulePlugin} CSSRulePlugin */
$(() => {
    const NEWER_INTERVAL = 1500;

    /**
     * Adds or removes 'first' and 'last' classes from messenger messages;
     *      also recalculates messageOffset;
     */
    function drawEdges() {
        messageOffset = 0;
        let $messages = $messenger__mainPanel.children();
        for (let i = 0; i < $messages.length; i++) {
            let $lastMessage = $($messages[ i - 1 ] || null).find('.messenger__msg'),
                $message = $($messages[ i ]).find('.messenger__msg'),
                $nextMessage = $($messages[ i + 1 ] || null).find('.messenger__msg');

            if ($message.length) {
                messageOffset++;

                let lastFrom = $lastMessage.data('from'),
                    from = $message.data('from'),
                    nextFrom = $nextMessage.data('from');

                if (lastFrom !== from) $message.addClass('first');
                else $message.removeClass('first');

                if (nextFrom !== from) $message.addClass('last');
                else $message.removeClass('last');
            }
        }
    }

    /**
     * Handles enter press when not holding shift
     * @param {jQuery.Event} event
     */
    function enterPress(event) {
        if (event.which === 13) {
            if (!event.shiftKey) {
                sendMessage(event);
                return false;
            }
        }
    }

    /**
     * Gets newer messages every NEWER_INTERVAL ms
     */
    function getNewerMessages() {
        if (getNewerRunning) return;
        getNewerRunning = true;

        let chatSelected = $('#chatSelected').val();

        $.ajax({
            url: `${baseUrl}/messenger/get_newer`,
            data: { chatSelected, messageOffset },
            dataType: 'json',
            method: 'GET',
            /** @param {{messages}} data */
            success: function (data) {
                let $append = $(data.messages);
                if ($append.length) {
                    $messenger__mainPanel.html('').append($append);

                    drawEdges();
                    scrollToBottom();
                }
            },
            complete: () => { getNewerRunning = false; }
        });
    }

    /**
     * Gets the updated chat lists
     */
    function getChatLists() {
        if (getChatsRunning) return;
        getChatsRunning = true;

        let chatSelected = $('#chatSelected').val();

        $.ajax({
            url: `${baseUrl}/messenger/get_chats`,
            data: { chatSelected },
            dataType: 'json',
            method: 'GET',
            /** @param {{chatLists}} data */
            success: function (data) {
                let $appendChatLists = $(data.chatLists);
                if ($appendChatLists.length)
                    $messenger__chatLists.html('').append($appendChatLists);
            },
            complete: () => { getChatsRunning = false; }
        });
    }

    /**
     * Gets the number of newer messages
     */
    function getNewerMessagesCount() {
        let chatSelected = $('#chatSelected').val();

        $.ajax({
            url: `${baseUrl}/messenger/get_newer_count`,
            data: { chatSelected },
            dataType: 'json',
            method: 'GET',
            /** @param {{all, chat}} data */
            success: function (data) {
                let $messageBadge = $('.message-badge');
                $messageBadge.html(data.all);
                if (data.all > 0) $messageBadge.removeClass('is-hidden');
                else $messageBadge.addClass('is-hidden');

                if ($messenger__mainPanel.length)
                    if (data.chat > 0) getNewerMessages();
                if ($messenger__chatLists.length)
                    if (data.chat > 0 || data.all > 0) getChatLists();

                setTimeout(getNewerMessagesCount, NEWER_INTERVAL);
            }
        });
    }

    /**
     * Gets older messages upon scrolling to the top
     */
    function getOlderMessages() {
        let panel = $messenger__mainPanel[ 0 ],
            shOld = panel.scrollHeight,
            stOld = panel.scrollTop;

        if (!allMessagesLoaded && stOld === 0) {
            // to prevent running again until the next set
            allMessagesLoaded = true;

            $messenger__mainPanel.prepend(
                "<div style='text-align: center;'>Loading... Please wait...</div>");

            let chatSelected = $('#chatSelected').val();

            $.ajax({
                url: `${baseUrl}/messenger/get_older`,
                data: { chatSelected, messageOffset },
                dataType: 'json',
                method: 'GET',
                /** @param {{messages}} data */
                success: function (data) {
                    let $prepend = $(data.messages);
                    if ($prepend.length) {
                        $messenger__mainPanel.html('').append($prepend);

                        let shDiff = panel.scrollHeight - shOld;
                        allMessagesLoaded = shDiff === 0;
                        $messenger__mainPanel.scrollTop(stOld + shDiff);

                        drawEdges();
                    }
                }
            });
        }
    }

    /**
     * Sends a message to another user or group
     * @param {jQuery.Event} event
     */
    function sendMessage(event) {
        const $target = $(event.target),
            $form = $target.closest('form'),
            formAction = $form.prop('action');

        let chatSelected = $('#chatSelected').val(),
            userMessage = $('#userMessage').val().trim(),
            userFiles = $('#userFile')[ 0 ].files;

        if (userMessage !== '' || userFiles.length > 0) {
            /**
             * Use FormData for multi-part forms
             * many thanks to:
             *      https://stackoverflow.com/a/5976031
             * @type {FormData}
             */
            let data = new FormData();

            data.append('chatSelected', chatSelected);
            data.append('messageOffset', messageOffset);
            if (userMessage !== '')
                data.append('userMessage', userMessage);
            if (userFiles.length)
                $.each(userFiles, function (i, file) {
                    data.append('userFile', file);
                });

            $.ajax({
                url: formAction,
                data: data,
                cache: false,
                contentType: false,
                dataType: 'json',
                processData: false,
                method: 'POST',
                /** @param {{chatLists, messages}} data */
                success: function (data) {
                    $form.trigger('reset');
                    let $appendMessages = $(data.messages),
                        $appendChatLists = $(data.chatLists);
                    if ($appendMessages.length) {
                        $messenger__mainPanel.html('').append($appendMessages);

                        drawEdges();
                        scrollToBottom();
                    }
                    if ($appendChatLists.length)
                        $messenger__chatLists.html('').append($appendChatLists);
                }
            });
        }
    }

    /**
     * Resize messenger__newMessage to it's necessary size;
     *      also adjusts max-height of messenger__scrollable
     * many thanks to: http://jsfiddle.net/CbqFv/2/
     * @param {jQuery.Event|*} event
     */
    function resize(event) {
        let clone = event.target.cloneNode();
        event.target.parentNode.insertBefore(clone, event.target);
        clone.style.height = 'auto';
        clone.value = event.target.value;
        let nmHeight = Math.min(clone.scrollTop + clone.scrollHeight + 2, nmMaxHeight);
        event.target.style.height = `${nmHeight}px`;
        event.target.parentNode.removeChild(clone);

        $messenger__scrollable.each((index, element) => {
            let hsMain = scMaxHeight.match(/calc\((.*?)\)/)[ 1 ];
            let heightStyle = `calc((${hsMain}) - (${nmHeight + 1}px + ${nmMarginTop + nmMarginBottom}px))`;
            element.style.maxHeight = heightStyle;
            element.style.minHeight = heightStyle;
        });
    }

    /**
     * 0 timeout to get the already changed text
     */
    let delayedResize = (event) => window.setTimeout(() => resize(event), 0);

    /**
     * Converts a rem style to px value;
     *      assumes in rem or px
     * @param {string} style
     * @returns {number}
     */
    let remToPx = (style) => {
        if (style.endsWith('rem'))
            return parseFloat(style) * 16;
        else return parseFloat(style);
    };

    /**
     * Scrolls to bottom of messenger__mainPanel
     */
    let scrollToBottom = () => {
        if ($messenger__mainPanel.length)
            $messenger__mainPanel.scrollTop($messenger__mainPanel[ 0 ].scrollHeight);
    };


    /**
     * extract baseUrl from location.href
     * many thanks to: https://stackoverflow.com/a/1420902
     */
    let pathArray = location.href.split('/'),
        protocol = pathArray[ 0 ], host = pathArray[ 2 ],
        baseUrl = `${protocol}//${host}`;

    let newMessageStyles = CSSRulePlugin.getRule('.messenger__newMessage'),
        scrollableStyles = CSSRulePlugin.getRule('.messenger__scrollable');

    let messageOffset = 0,
        getChatsRunning = false,
        getNewerRunning = false,
        allMessagesLoaded = false;

    let nmMaxHeight = remToPx(newMessageStyles.maxHeight),
        nmMarginTop = remToPx(newMessageStyles.marginTop),
        nmMarginBottom = remToPx(newMessageStyles.marginBottom),
        scMaxHeight = scrollableStyles.maxHeight;

    $.post(`${baseUrl}/api/courses`);
    $.post(`${baseUrl}/api/students`);

    let $messenger__newMessage = $('.messenger__newMessage'),
        $messenger__scrollable = $('.messenger__scrollable'),
        $messenger__mainPanel = $('.messenger__mainPanel'),
        $messenger__chatLists = $('.messenger__chatLists');

    $(document).on({ 'keypress': enterPress });

    $messenger__newMessage.each((index, element) => resize({ target: element }));
    $messenger__newMessage.on({
        'change': resize,
        'cut': delayedResize,
        'drop': delayedResize,
        'keydown': delayedResize,
        'paste': delayedResize,
    });

    $messenger__mainPanel.on({ 'scroll': getOlderMessages });

    scrollToBottom();
    drawEdges();

    setTimeout(getNewerMessagesCount, NEWER_INTERVAL);
});