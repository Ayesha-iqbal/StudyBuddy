<?php class Migration_Add_user_and_course_info extends MY_Migration
{
    public function up()
    {
        //region add course fields
        $fields = array(
            'course_code' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
            'name' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
            'start_at' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
            'end_at' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
            'enrolled_students' => array('type' => 'TEXT'),
        );
        $this->dbforge->add_column('courses', $fields);
        //endregion
        //region add user fields
        $fields = array(
            'name' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
            'short_name' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
            'sortable_name' => array(
                'type' => 'VARCHAR',
                'constraint' => 255),
        );
        $this->dbforge->add_column('users', $fields);
        //endregion
        //region add new course properties from json
        $courses = $this->db->get('courses')->result_array();
        $updateCourses = array();
        foreach ($courses as $course) {
            $json = json_decode($course['json'], true);
            $course['course_code'] = $json['course_code'];
            $course['name'] = $json['name'];
            $course['start_at'] = $json['start_at'];
            $course['end_at'] = $json['end_at'];
            $updateCourses[] = $course;
        }
        if (count($updateCourses))
            $this->db->update_batch('courses', $updateCourses, 'id');
        //endregion
        //region add new user properties from json
        $users = $this->db->get('users')->result_array();
        $updateUsers = array();
        foreach ($users as $user) {
            $json = json_decode($user['json'], true);
            $user['name'] = $json['name'];
            $user['short_name'] = $json['short_name'];
            $user['sortable_name'] = $json['sortable_name'];
            $updateUsers[] = $user;
        }
        if (count($updateUsers))
            $this->db->update_batch('users', $updateUsers, 'id');
        //endregion
    }

    public function down()
    {
        $this->_dropColumns(array(
            'users' => array('name', 'short_name', 'sortable_name'),
            'courses' => array('course_code', 'name', 'start_at', 'end_at', 'enrolled_students'),
        ));
    }
}