<?php class Migration_Add_chat_list_table extends MY_Migration
{
    public function up()
    {
        // chat_lists table
        $this->dbforge->add_field(array(
            'id' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'auto_increment' => true),
            'json' => array('type' => 'TEXT'),

            'message_id' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true),
            'user_id' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true),

            'to' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'null' => true),
            'to_group' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'null' => true),
        ));
        $this->dbforge->add_key('id', true);
        $this->dbforge->create_table('chat_lists');
    }

    public function down() { $this->dbforge->drop_table('chat_lists', true); }
}