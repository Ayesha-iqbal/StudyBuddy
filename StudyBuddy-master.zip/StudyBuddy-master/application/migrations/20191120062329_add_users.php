<?php class Migration_Add_users extends MY_Migration
{
    public function up()
    {
        // users table
        $this->dbforge->add_field(array(
            'id' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true),
            'json' => array('type' => 'TEXT'),
        ));
        $this->dbforge->add_key('id', true);
        $this->dbforge->create_table('users');
    }

    public function down() { $this->dbforge->drop_table('users', true); }
}