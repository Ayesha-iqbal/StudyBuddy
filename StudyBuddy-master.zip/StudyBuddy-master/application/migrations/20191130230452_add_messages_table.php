<?php class Migration_Add_messages_table extends MY_Migration
{
    public function up()
    {
        // messages table
        $this->dbforge->add_field(array(
            'id' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'auto_increment' => true),
            'json' => array('type' => 'TEXT'),

            'from' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true),
            'to' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'null' => true),
            'to_group' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'null' => true),
            'status' => array(
                'type' => 'CHAR',
                'constraint' => 1),
            'timestamp' => array(
                'type' => 'DECIMAL',
                'constraint' => array(14, 4),
                'unsigned' => true),

            'media_type' => array(
                'type' => 'CHAR',
                'constraint' => 1),
            'data' => array(
                'type' => 'TEXT',
                'null' => true),
            'media_url' => array(
                'type' => 'VARCHAR',
                'constraint' => 127,
                'null' => true),
            'media_size' => array(
                'type' => 'DECIMAL',
                'constraint' => array(9, 2),
                'unsigned' => true,
                'null' => true),
            'media_name' => array(
                'type' => 'VARCHAR',
                'constraint' => 127,
                'null' => true),
        ));
        $this->dbforge->add_key('id', true);
        $this->dbforge->create_table('messages');
    }

    public function down() { $this->dbforge->drop_table('messages', true); }
}