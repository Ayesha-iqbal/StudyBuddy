<?php class Migration_Initial_schema extends MY_Migration
{
    public function up()
    {
        // courses table
        $this->dbforge->add_field(array(
            'id' => array(
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true),
            'json' => array('type' => 'TEXT'),
        ));
        $this->dbforge->add_key('id', true);
        $this->dbforge->create_table('courses');
    }

    public function down() { $this->dbforge->drop_table('courses', true); }
}