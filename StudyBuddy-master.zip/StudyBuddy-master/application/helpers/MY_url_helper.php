<?php if (!function_exists('assets_url')) {
    /**
     * Gets the absolute url to the assets directory
     * @param string $uri - URI string
     * @param string $protocol - Protocol, e.g. 'http' or 'https'
     * @return string
     */
    function assets_url($uri = '', $protocol = null)
    {
        return base_url('assets/' . $uri, $protocol);
    }
}

if (!function_exists('images_url')) {
    /**
     * Gets the absolute url to the assets/images directory
     * @param string $uri - URI string
     * @param string $protocol - Protocol, e.g. 'http' or 'https'
     * @return string
     */
    function images_url($uri = '', $protocol = null)
    {
        return assets_url('images/' . $uri, $protocol);
    }
}

if (!function_exists('javascripts_url')) {
    /**
     * Gets the absolute url to the assets/javascripts directory
     * @param string $uri - URI string
     * @param string $protocol - Protocol, e.g. 'http' or 'https'
     * @return string
     */
    function javascripts_url($uri = '', $protocol = null)
    {
        return assets_url('javascripts/' . $uri, $protocol);
    }
}

if (!function_exists('stylesheets_url')) {
    /**
     * Gets the absolute url to the assets/stylesheets directory
     * @param string $uri - URI string
     * @param string $protocol - Protocol, e.g. 'http' or 'https'
     * @return string
     */
    function stylesheets_url($uri = '', $protocol = null)
    {
        return assets_url('stylesheets/' . $uri, $protocol);
    }
}
