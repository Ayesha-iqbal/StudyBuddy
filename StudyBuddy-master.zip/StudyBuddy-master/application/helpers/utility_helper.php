<?php

if (!function_exists('ends_with')) {
    /**
     * Determines if a $haystack ends with the $needle
     *      credit: https://stackoverflow.com/a/834355
     * @param string $haystack
     * @param string $needle
     * @return bool
     */
    function ends_with($haystack, $needle)
    {
        $length = strlen($needle);
        if ($length == 0) return true;

        return substr($haystack, -$length) === $needle;
    }
}

if (!function_exists('guid')) {
    /**
     * Generates a unique(ish) id
     *      credit: https://stackoverflow.com/a/105074
     * @return string
     */
    function guid()
    {
        return s4() . s4() . '-' . s4() . '-' . s4() . '-' .
            s4() . '-' . s4() . s4() . s4();
    }
}

if (!function_exists('is_json')) {
    /**
     * Determines if a string is valid json
     *      credit: https://stackoverflow.com/a/6041773
     * @param string $string
     * @return bool
     */
    function is_json($string)
    {
        json_decode($string);
        return (json_last_error() === JSON_ERROR_NONE);
    }
}

if (!function_exists('pretty_dump')) {
    /**
     * Var_dumps one or more $objects in a <pre></pre> block
     * @param array $objects
     */
    function pretty_dump(...$objects)
    {
        foreach ($objects as $object) {
            echo "<pre>";
            var_dump($object);
            echo "</pre>";
        }
    }
}

if (!function_exists('s4')) {
    /**
     * Generates a 4 digit hex number as a string
     * @return string
     */
    function s4()
    {
        $rand = rand(65536, 131071);
        $hex = dechex(floor($rand));
        return substr($hex, 1);
    }
}

if (!function_exists('starts_with')) {
    /**
     * Determines if a $haystack starts with the $needle
     *      credit: https://stackoverflow.com/a/834355
     * @param string $haystack
     * @param string $needle
     * @return bool
     */
    function starts_with($haystack, $needle)
    {
        $length = strlen($needle);
        return substr($haystack, 0, $length) === $needle;
    }
}

if (!function_exists('strip_non_class_values')) {
    /**
     * Removes properties from an object that are not in its class;
     *      also applies strip_null_values
     *
     * @param object
     * @return array
     */
    function strip_non_class_values($object)
    {
        if (!is_object($object)) return $object;

        $array = array();
        $objectVars = get_object_vars($object);
        foreach (get_class_vars(get_class($object)) as $key => $null) {
            $val = $objectVars[$key] ?? null;

            // There are some built in keys we need to ignore for this conversion
            if (!is_null($val) && !is_object($val) && !is_array($val) && $key !== '_parent_name')
                $array[$key] = $val;
        }

        return $array;
    }
}

if (!function_exists('strip_null_values')) {
    /**
     * Strips null values and converts an object to an array
     *
     * Takes an object as input and converts the class variables to array key/vals
     *
     * Modified version of CI_DB_query_builder::_object_to_array
     *
     * @param object
     * @return array
     */
    function strip_null_values($object)
    {
        if (!is_object($object)) return $object;

        $array = array();
        foreach (get_object_vars($object) as $key => $val) {
            // There are some built in keys we need to ignore for this conversion
            if (!is_null($val) && !is_object($val) && !is_array($val) && $key !== '_parent_name')
                $array[$key] = $val;
        }

        return $array;
    }
}