<?php class Header
{
    /**
     * CI Singleton
     *
     * @var MY_Controller
     */
    private $CI;

    /**
     * Describes shared 'openGraphProps' for a header
     * @var array $ogProps
     */
    private $ogProps = array();

    /**
     * Describes what to load into the 'header-bar' view
     * @var array $headerBar
     */
    public $headerBar = array();
    /**
     * Describes what to load into the 'footer' view
     * @var array $footer
     */
    public $footer = array();

    /**
     * Header constructor.
     */
    public function __construct()
    {
        $this->CI =& get_instance();

        $this->CI->load->model('message_model');

        $cTokenSet = !is_null($this->CI->session->userdata('canvasToken'));

        if ($cTokenSet) {
            $logInOutContent = 'Logout';
            $logInOutUrl = 'dashboard/logout';
        } else {
            $logInOutContent = 'Login';
            $logInOutUrl = 'dashboard/login';
        }

        $messagesEle = ($cTokenSet) ? array(
            'class' => 'position-relative',
            'content' => 'Messages',
            'href' => base_url('messenger/s'),
            'enabled' => true,
            'desktopOnly' => false,
            'mobileOnly' => false,
        ) : array('enabled' => false);
        $menuBarItems = array(array(
            'class' => '',
            'content' => 'Classes',
            'href' => base_url('dashboard/courses'),
            'enabled' => true,
            'desktopOnly' => false,
            'mobileOnly' => false,
        ), array(
            'class' => '',
            'content' => 'Study Groups',
            'href' => base_url('dashboard/study-groups'),
            'enabled' => true,
            'desktopOnly' => false,
            'mobileOnly' => false,
        ), $messagesEle, array(
            'class' => '',
            'content' => $logInOutContent,
            'href' => base_url($logInOutUrl),
            'enabled' => true,
            'desktopOnly' => false,
            'mobileOnly' => false,
        ));

        $this->headerBar['default'] = array(
            'menuBarItems' => $menuBarItems,
            'unreadCount' => $this->CI->message_model->getUnreadCount());
        $this->footer['emptyLinks'] = array('links' => array());
    }

    public function dashboard__index()
    {
        $header = array('title' => 'StudyBuddies');
        return $this->_loadViews($header);
    }

    public function dashboard__course($courseName)
    {
        $header = array('title' => "{$courseName} | StudyBuddies");
        return $this->_loadViews($header);
    }

    public function dashboard__student($studentName)
    {
        $header = array('title' => "{$studentName} | StudyBuddies");
        return $this->_loadViews($header);
    }

    public function dashboard__login()
    {
        $header = array('title' => 'Login | StudyBuddies');
        return $this->_loadViews($header);
    }

    public function messenger__index()
    {
        $header = array('title' => 'Messenger | StudyBuddies');
        return $this->_loadViews($header);
    }

    private function _loadViews($header)
    {
        // add base to the start of every page
        $header['assets'][] = $this->CI->load->view('headers/base', null, true);
        $header['assets'][] = $this->CI->load->view('headers/home', null, true);
        $header['assets'][] = $this->CI->load->view('headers/init', null, true);
        return $header;
    }
}