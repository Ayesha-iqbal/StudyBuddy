<?php use \LibExtend\Custom_api;

class Canvas extends Custom_api
{
    /**
     * CI Singleton
     *
     * @var MY_Controller
     */
    private $CI;

    protected $canvasToken;

    /**
     * Canvas constructor.
     */
    public function __construct()
    {
        $this->CI = get_instance();
        try {
            parent::__construct(array(
                'canvasToken' => 'CANVAS_TOKEN'));
        } catch (Exception $e) {
            $this->setToken();
        }
    }

    public function getCourses() { return $this->_request('courses'); }

    public function getStudents($courseId) { return $this->_request("courses/{$courseId}/students"); }

    public function getUserProfile($user_id = 'self') { return $this->_request("users/{$user_id}/profile"); }

    /**
     * Attempts to set the canvas token
     *      to session->userdata('canvasToken');
     * @return bool|array true if set, errors array otherwise
     */
    public function setToken()
    {
        $canvasToken = $this->CI->session->userdata('canvasToken');
        if (!is_null($canvasToken)) {
            $this->canvasToken = $canvasToken;
            return true;
        } else return array('errors' => array(array('message' => 'Missing access token.')));
    }

    /**
     * Makes a request from a canvas endpoint
     * @param string $endpoint
     * @param array $parameters
     * @return array
     */
    private function _request($endpoint, $parameters = array())
    {
        if (!isset($this->canvasToken)) {
            $setTokenResult = $this->setToken();
            if ($setTokenResult !== true) return $setTokenResult;
        }
        $parameters = array_merge($parameters, array('per_page' => 1000));
        $request = $this->_getRequest($this->canvasToken, 'https://sjsu.instructure.com/api/v1');
        return $request($endpoint, $parameters);
    }
}