<?php class MY_Upload extends CI_Upload
{
    /**
     * Gets the max allowed bytes for an upload;
     *      based on upload_max_filesize, post_max_size, and memory_limit
     * @return int
     */
    public function get_max_upload_bytes()
    {
        $iniToBytes = function ($iniKey) {
            $iniValue = ini_get($iniKey);
            $iniValue = str_split($iniValue, strspn($iniValue, '1234567890'));

            if (!empty($iniValue[1])) {
                switch ($iniValue[1][0]) {
                    case 'g':
                    case 'G':
                        $iniValue[0] *= 1024 * 1024 * 1024;
                        break;
                    case 'm':
                    case 'M':
                        $iniValue[0] *= 1024 * 1024;
                        break;
                    case 'k':
                    case 'K':
                        $iniValue[0] *= 1024;
                        break;
                    default:
                        break;
                }
            }

            return $iniValue[0];
        };

        return min($iniToBytes('upload_max_filesize'),
            $iniToBytes('post_max_size'), $iniToBytes('memory_limit'));
    }

    /**
     * Gets the max allowed size for an upload;
     *      returns as a string where the number is 'XXX.XX XB',
     *          where XB is either 'GB', 'MB', 'KB', or 'B'
     * @return string
     */
    public function get_max_upload_size()
    {
        $uploadMaxBytes = $this->get_max_upload_bytes();
        return byte_format($uploadMaxBytes, 2);
    }
}
