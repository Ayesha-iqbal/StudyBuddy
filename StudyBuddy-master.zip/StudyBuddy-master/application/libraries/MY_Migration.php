<?php

/**
 * Custom Migration class used to implement auto-running migrations to current version
 * Class MY_Migration
 *
 * @property CI_DB_query_builder|CI_DB_postgre_driver $db
 * @property CI_DB_forge $dbforge
 * @property CI_Lang $lang
 * @property MY_Loader $load
 */
class MY_Migration extends CI_Migration
{
    /**
     * Whether to automatically run migrations to current version
     *
     * @var bool
     */
    protected $_migration_auto_current = false;

    /**
     * Initialize MY_Migration Class
     *
     * @param array $config
     * @return void
     */
    public function __construct($config = array())
    {
        parent::__construct($config);

        // If _migration_path not set, set it; add trailing slash as necessary
        if ($this->_migration_path === '' || is_null($this->_migration_path))
            $this->_migration_path = APPPATH . 'migrations/';
        $this->_migration_path = rtrim($this->_migration_path, '/') . '/';

        $this->load->database();
        $this->load->dbforge();

        // Do we auto migrate to the current migration?
        if ($this->_migration_auto_current === true && !$this->current())
            show_error($this->error_string());
    }

    /**
     * Retrieves list of available migration scripts;
     *      allows searching in subdirectories of migrations path
     *
     * @return array list of migration file paths sorted by version
     */
    public function find_migrations()
    {
        $searchDirs = array_merge(array($this->_migration_path),
            glob("{$this->_migration_path}*/", GLOB_ONLYDIR));

        $migrations = array();
        // Load all *_*.php files in the migrations path
        foreach ($searchDirs as $searchDir) {
            foreach (glob("{$searchDir}*_*.php") as $file) {
                $name = basename($file, '.php');

                // Filter out non-migration files
                if (preg_match($this->_migration_regex, $name)) {
                    $number = $this->_get_migration_number($name);

                    // There cannot be duplicate migration numbers
                    if (isset($migrations[$number])) {
                        $this->_error_string = sprintf($this->lang->line('migration_multiple_version'), $number);
                        show_error($this->_error_string);
                    }

                    $migrations[$number] = $file;
                }
            }
        }

        ksort($migrations);
        return $migrations;
    }

    /**
     * Drops columns from specified tables
     * @param array $dropColumns
     */
    protected function _dropColumns($dropColumns = array())
    {
        foreach ($dropColumns as $table => $columns)
            foreach ($columns as $dropColumn)
                $this->dbforge->drop_column($table, $dropColumn);
    }
}
