<?php namespace LibExtend;

use \Closure;
use \Exception;

class Custom_api
{
    /**
     * Custom_api constructor.
     * @param array $map
     * @throws Exception
     */
    public function __construct($map = array()) { $this->_setVariables($map); }

    /**
     * Returns a function which makes a request from a specified endpoint
     * @param array $accessToken
     * @param string $url without trailing slash
     * @param string|null $errorKey
     * @return Closure
     */
    protected function _getRequest($accessToken, $url, $errorKey = null)
    {
        return function ($endpoint, $parameters = array()) use ($accessToken, $url, $errorKey) {
            $query = http_build_query($parameters);
            $response = $this->_curl(array(
                'header' => array("Authorization: Bearer {$accessToken}"),
                'url' => "{$url}/{$endpoint}?{$query}"));

            $decodedResponse = json_decode($response, true);
            if (is_null($decodedResponse)) throw new Exception($response, 400);

            if (!is_null($errorKey)) {
                if (isset($decodedResponse[$errorKey]))
                    throw new Exception($decodedResponse[$errorKey], 400);
                else {
                    // handling errors present multiple layers down
                    $errorKeys = explode('/', $errorKey);
                    $tempError = $decodedResponse;
                    foreach ($errorKeys as $eKey) {
                        if (isset($tempError[$eKey]))
                            $tempError = $tempError[$eKey];
                        else break;
                    }

                    if (is_string($tempError))
                        throw new Exception($tempError, 400);
                }
            }

            return $decodedResponse;
        };
    }

    /**
     * Curl wrapper with some default options
     * @param array $config
     * @return string
     * @throws Exception if there's an error
     */
    private function _curl($config)
    {
        $curl = curl_init();

        if (!isset($config['url'])) throw new Exception('$config not configured correctly');
        $config['request'] = $config['request'] ?? 'GET';

        curl_setopt_array($curl, array(
            CURLOPT_URL => $config['url'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $config['request']));
        if (isset($config['header']))
            curl_setopt($curl, CURLOPT_HTTPHEADER, $config['header']);
        if (isset($config['post_fields']))
            curl_setopt($curl, CURLOPT_POSTFIELDS, $config['post_fields']);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) throw new Exception($err);
        else return $response;
    }

    /**
     * Sets variables used by custom_api;
     * @param array $map
     * @throws Exception
     */
    private function _setVariables($map = array())
    {
        foreach ($map as $thisProp => $serverKey) {
            if (!isset($_SERVER[$serverKey]))
                throw new Exception("'$serverKey' not set", 400);
            $this->$thisProp = $_SERVER[$serverKey];
        }
    }
}