<?php namespace Models;

use \MY_Model;
use \Objects\Chat_list;

/**
 * Database interaction for chat_lists;
 * Class Chat_list_model
 */
class Chat_list_model extends MY_Model
{
    // model is in charge of crud: create, read, update, delete
    public function __construct()
    {
        parent::__construct();

        $this->load->model(array('message_model', 'user_model'));
    }

    /**
     * Gets the chat_lists with the given properties from the database;
     *      only allows chat_lists for the user
     * @param array $where
     * @return Chat_list[]
     */
    public function getUserChatLists()
    {
        $studentId = +$this->session->userdata('studentId');
        $this->db->where("{$this->_table_name}.user_id", $studentId);
        return $this->getChatLists();
    }

    /**
     * Gets the chat_lists with the given properties from the database
     * @param array $where
     * @return Chat_list[]
     */
    public function getChatLists($where = array())
    {
        $c = $this->_table_name;
        $m = $this->message_model->_table_name;
        $u = $this->user_model->_table_name;

        $selectPre = array(
            $c => array_keys(get_class_vars($this->_result_object)),
            $m => array('from', 'data as message', 'status', 'timestamp', 'media_type'),
            $u => array('name as user_name'));

        $this->db->select($this->_compileSelect($selectPre))
            ->join($m, "{$m}.id = {$c}.message_id", 'inner')
            ->join($u, "{$u}.id = {$c}.to", 'left')
            ->order_by('timestamp', 'DESC');
        return $this->_getWhere($where);
    }

    /**
     * Updates a chat_list if it exists;
     *      if not, creates it
     * @param Chat_list $chatList
     */
    public function updateChatList($chatList) { $this->_updateRow($chatList); }

    /**
     * Updates chat_lists if they exist;
     *      if not, creates them
     * @param Chat_list[] $chatLists
     */
    public function updateChatLists($chatLists) { $this->_updateRows($chatLists); }
}