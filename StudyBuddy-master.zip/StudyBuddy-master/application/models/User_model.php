<?php namespace Models;

use \MY_Model;
use \Objects\User;

/**
 * Database interaction for users;
 * Class User_model
 */
class User_model extends MY_Model
{
    // model is in charge of crud: create, read, update, delete
    public function __construct() { parent::__construct(); }

    /**
     * Gets the user with the given properties from the database;
     * @param array $where
     * @return User
     */
    public function getUser($where = array()) { return $this->_getWhereRow($where); }

    /**
     * Gets the users with the given properties from the database;
     *      sorts by sortable_name
     * @param array $where
     * @return User[]
     */
    public function getUsers($where = array())
    {
        $users = $this->_getWhere($where);
        usort($users, function ($a, $b) {
            return strcmp($a->sortable_name, $b->sortable_name);
        });

        return $users;
    }

    /**
     * Updates a user if they exist;
     *      if not, creates them
     * @param User $user
     */
    public function updateUser($user) { $this->_updateRow($user); }

    /**
     * Updates users if they exist;
     *      if not, creates them
     * @param User[] $users
     */
    public function updateUsers($users) { $this->_updateRows($users); }
}