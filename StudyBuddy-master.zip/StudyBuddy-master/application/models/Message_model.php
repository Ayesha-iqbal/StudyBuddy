<?php namespace Models;

use \MY_Model;
use \Objects\Message;

/**
 * Database interaction for messages;
 * Class Message_model
 */
class Message_model extends MY_Model
{
    // model is in charge of crud: create, read, update, delete
    public function __construct() { parent::__construct(); }

    /**
     * Gets the number of unread messages from the database;
     *      filters based on studentId
     * @return int
     */
    public function getUnreadCount()
    {
        if (!$this->db->table_exists($this->_table_name)) return 0;

        $studentId = +$this->session->userdata('studentId');
        // todo(2019-11-30): take groups into account
        return $this->db->where('status', 1)
            ->where('to', $studentId)
            ->count_all_results($this->_table_name);
    }

    /**
     * Gets the messages from the database;
     *      only allows messages which are:
     *          to or from the current user,
     *          AND to or from a specified user
     * @param int|null $userId other user in conversation
     * @param int|null $limit
     * @param int $offset
     * @return Message[]
     */
    public function getUserMessages($userId = null, $limit = null, $offset = 0)
    {
        $studentId = +$this->session->userdata('studentId');
        $this->db->limit($limit, $offset)
            ->order_by('timestamp', 'DESC')
            ->where(/** @lang SQL */ "(`from` = {$studentId} OR `to` = {$studentId})");
        if (!is_null($userId)) {
            $userId = +$userId;
            $this->db->where(/** @lang SQL */ "(`from` = {$userId} OR `to` = {$userId})");
        }
        return $this->_getWhere(null);
    }

    /**
     * Gets the messages from the database;
     *      only allows messages which are:
     *          to the current user,
     *          AND to or from a specified user
     * @param int|null $userId other user in conversation
     * @return Message[]
     */
    public function getNewUserMessages($userId = null)
    {
        $studentId = +$this->session->userdata('studentId');
        $this->db->where(array('status' => '1', 'to' => $studentId));
        return $this->getUserMessages($userId);
    }

    /**
     * Updates a message if it exists;
     *      if not, creates it
     * @param Message $message
     */
    public function updateMessage($message) { $this->_updateRow($message); }

    /**
     * Updates messages if they exist;
     *      if not, creates them
     * @param Message[] $messages
     */
    public function updateMessages($messages) { $this->_updateRows($messages); }
}