<?php namespace Models;

use \MY_Model;
use \Objects\Course;

/**
 * Database interaction for courses;
 * Class Course_model
 */
class Course_model extends MY_Model
{
    // model is in charge of crud: create, read, update, delete
    public function __construct() { parent::__construct(); }

    /**
     * Filters courses so only active courses remain
     * @param Course[] $courses
     * @return Course[]
     */
    public function filterCurrent($courses)
    {
        return array_filter($courses, function ($course) {
            return strtotime($course->end_at) >= time();
        });
    }

    /**
     * Filters courses so only previous courses remain
     * @param Course[] $courses
     * @return Course[]
     */
    public function filterPrevious($courses)
    {
        return array_filter($courses, function ($course) {
            return strtotime($course->end_at) < time();
        });
    }

    /**
     * Gets the course with the given properties from the database;
     * @param array $where
     * @return Course
     */
    public function getCourse($where = array()) { return $this->_getWhereRow($where); }

    /**
     * Gets the courses with the given properties from the database;
     * @param array $where
     * @return Course[]
     */
    public function getCourses($where = array()) { return $this->_getWhere($where); }

    /**
     * Gets the active courses with the given properties from the database;
     * @param array $where
     * @return Course[]
     */
    public function getCoursesCurrent($where = array())
    {
        $courses = $this->getCourses($where);
        return $this->filterCurrent($courses);
    }

    /**
     * Gets the previous courses with the given properties from the database;
     * @param array $where
     * @return Course[]
     */
    public function getCoursesPrevious($where = array())
    {
        $courses = $this->getCourses($where);
        return $this->filterPrevious($courses);
    }

    /**
     * Updates a course if it exists;
     *      if not, creates it
     * @param Course $course
     */
    public function updateCourse($course) { $this->_updateRow($course); }

    /**
     * Updates courses if they exist;
     *      if not, creates them
     * @param Course[] $courses
     */
    public function updateCourses($courses) { $this->_updateRows($courses); }
}