<?php

/**
 * Custom Loader class used primarily to implement namespaces in models
 * Class MY_Loader
 */
class MY_Loader extends CI_Loader
{
    /**
     * CI Singleton
     *
     * @var MY_Controller
     */
    public $CI;

    /**
     * Initialize MY_Loader Class
     */
    public function __construct()
    {
        parent::__construct();
        $this->CI =& get_instance();
    }

    /**
     * Library Loader
     *
     * Loads and instantiates libraries.
     * Designed to be called from application controllers.
     *
     * @param string|array $library Library name
     * @param array $params Optional parameters to pass to the library class constructor
     * @param string $object_name An optional object name to assign to
     * @return object
     */
    public function library($library, $params = null, $object_name = null)
    {
        //region don't load libraries a second time; prevents CI logging slowdown
        if (is_array($library) && is_null($object_name)) {
            foreach ($library as $key => $lib)
                if (isset($this->_ci_classes[$lib])) unset($library[$key]);
        } else if (isset($this->_ci_classes[$library]) && is_null($object_name)) return $this;
        //endregion

        if (empty($library)) return $this;
        else if (is_array($library)) {
            foreach ($library as $key => $value) {
                if (is_int($key)) $this->library($value, $params);
                else $this->library($key, $params, $value);
            }
            return $this;
        }

        if ($params !== null && !is_array($params)) $params = null;
        parent::_ci_load_library($library, $params, $object_name);

        return $this;
    }

    /**
     * Model Loader
     *
     * Loads and instantiates models.
     *
     * @param string|array $model Model name; array of Model names
     * @param string $name An optional object name to assign to
     * @param bool $db_conn An optional database connection configuration to initialize
     * @return object
     */
    public function model($model, $name = '', $db_conn = false)
    {
        /**
         * Automatically loads the required model
         * @param string $definedModel
         * @param string $modelPath
         */
        $autoloadModel = function ($definedModel, $modelPath) {
            if (!class_exists($definedModel, false)) {
                foreach ($this->_ci_model_paths as $modPath) {
                    if (!file_exists("{$modPath}models/{$modelPath}.php")) continue;

                    require_once("{$modPath}models/{$modelPath}.php");
                    if (!class_exists($definedModel, false)) throw new RuntimeException("{$modPath}models/{$modelPath}.php exists, but doesn't declare class {$definedModel}");
                    break;
                }

                if (!class_exists($definedModel, false)) throw new RuntimeException("Unable to locate the model you have specified: {$definedModel}");
            } else if (!is_subclass_of($definedModel, 'CI_Model')) throw new RuntimeException("Class {$definedModel} already exists and doesn't extend CI_Model");
        };

        /**
         * Initializes database loader if $dbConnection isn't false
         * @param string|bool $dbConnection
         */
        $dbConn = function ($dbConnection) {
            if ($dbConnection !== false && !class_exists('CI_DB', false)) {
                if ($dbConnection === true) $dbConnection = '';
                $this->database($dbConnection, false, true);
            }
        };

        /**
         * Formats model and name into a few different parameters
         * @param string $model
         * @param string $name
         * @return array
         */
        $formatModel = function ($model, $name) {
            $path = '';
            // default namespace for models
            $namespace = '\\Models\\';

            // Is the model in a sub-folder? If so, parse out the filename and path.
            if (($lastSlash = strrpos($model, '/')) !== false) {
                // The path is in front of the last slash
                $path = substr($model, 0, ++$lastSlash);

                // And the model name behind it
                $model = substr($model, $lastSlash);
            }

            // Does the model have a namespace? If so, parse out the filename and path.
            if (($lastFSlash = strrpos($model, '\\')) !== false) {
                // The namespace is in front of the last slash
                $namespace = substr($model, 0, ++$lastFSlash);

                // And the model name behind it
                $model = substr($model, $lastFSlash);
            }

            // sets name to model name
            if (empty($name)) $name = $model;

            return array(
                'path' => $path,
                'model' => $model,
                'name' => $name,
                'namespace' => $namespace,
            );
        };

        /**
         * Loads overwritten, and extended model core file
         */
        $loadModelExtend = function () {
            if (!class_exists('CI_Model', false)) {
                $appPath = APPPATH . 'core' . DIRECTORY_SEPARATOR;
                if (file_exists("{$appPath}Model.php")) {
                    require_once("{$appPath}Model.php");
                    if (!class_exists('CI_Model', false)) throw new RuntimeException("{$appPath}Model.php exists, but doesn't declare class CI_Model");
                } else if (!class_exists('CI_Model', false)) {
                    require_once(BASEPATH . 'core' . DIRECTORY_SEPARATOR . 'Model.php');
                }

                $class = config_item('subclass_prefix') . 'Model';
                if (file_exists("{$appPath}{$class}.php")) {
                    require_once("{$appPath}{$class}.php");
                    if (!class_exists($class, false)) throw new RuntimeException("{$appPath}{$class}.php exists, but doesn't declare class {$class}");
                }
            }
        };

        /**
         * Quits if $model is empty or an array
         *      creates models from it if it's an array
         *      returns null if it shouldn't quit
         * @param string|array $model
         * @param string|bool $dbConnection
         * @return object|bool
         */
        $quitIf = function ($model, $dbConnection) {
            if (empty($model)) {
                // quits if $model is empty
                return $this;
            } else if (is_array($model)) {
                // loops through if $model is an array
                foreach ($model as $key => $value) {
                    if (is_int($key)) {
                        // meaningless keys
                        $this->model($value, '', $dbConnection);
                    } else {
                        // keys are model names, values are names to assign
                        $this->model($key, $value, $dbConnection);
                    }
                }
                return $this;
            }
            return false;
        };


        $shouldQuit = $quitIf($model, $db_conn);
        if ($shouldQuit !== false) return $shouldQuit;

        $formatted = $formatModel($model, $name);
        $path = $formatted['path'];
        $model = $formatted['model'];
        $name = $formatted['name'];
        $namespace = $formatted['namespace'];

        // quits if model initialized
        if (in_array($name, $this->_ci_models, true)) return $this;

        if (isset($this->CI->$name)) throw new RuntimeException("The model name you are loading is the name of a resource that is already being used: {$name}");

        $dbConn($db_conn);
        $loadModelExtend();

        $model = ucfirst($model);
        $modelPath = $path . $model;
        $definedModel = $namespace . $model;
        $autoloadModel($definedModel, $modelPath);

        $this->_ci_models[] = $name;
        $this->CI->$name = new $definedModel();
        return $this;
    }
}