<?php

use \Models\Chat_list_model;
use \Models\Course_model;
use \Models\Message_model;
use \Models\User_model;
use \Objects\Json_base;

/**
 * @property CI_DB_query_builder|CI_DB_postgre_driver $db
 *      This is the platform-independent base Active Record implementation class.
 * @property CI_DB_forge $dbforge
 *      Database Utility Class
 * @property CI_User_agent $agent
 *      Identifies the platform, browser, robot, or mobile devise of the browsing agent
 * @property CI_Benchmark $benchmark
 *      This class enables you to mark points and calculate the time difference between them.
 *      Memory consumption can also be displayed.
 * @property CI_Cache $cache
 *      This class enables the usage of caches
 * @property CI_Calendar $calendar
 *      This class enables the creation of calendars
 * @property CI_Cart $cart
 *      Shopping Cart Class
 * @property CI_Config $config
 *      This class contains functions that enable config files to be managed
 * @property CI_Controller $controller
 *      This class object is the super class that every library in.
 *      CodeIgniter will be assigned to.
 * @property CI_Email $email
 *      Permits email to be sent using Mail, Sendmail, or SMTP.
 * @property CI_Encrypt $encrypt
 *      Provides two-way keyed encoding using XOR Hashing and Mcrypt
 * @property CI_Exceptions $exceptions
 *      Exceptions Class
 * @property CI_Form_validation $form_validation
 *      Form Validation Class
 * @property CI_Ftp $ftp
 *      FTP Class
 * @property CI_Hooks $hooks
 *      Provides a mechanism to extend the base system without hacking.
 * @property CI_Image_lib $image_lib
 *      Image Manipulation class
 * @property MY_Input $input
 *      Pre-processes global input data for security
 * @property CI_Lang $lang
 *      Language Class
 * @property MY_Loader $load
 *      Loads views and files
 * @property CI_Log $log
 *      Logging Class
 * @property MY_Model $model
 *      CodeIgniter Model Class
 * @property CI_Output $output
 *      Responsible for sending final output to browser
 * @property CI_Pagination $pagination
 *      Pagination Class
 * @property CI_Parser $parser
 *      Parses pseudo-variables contained in the specified template view,
 *      replacing them with the data in the second param
 * @property CI_Profiler $profiler
 *      This class enables you to display benchmark, query, and other data
 *      in order to help with debugging and optimization.
 * @property CI_Router $router
 *      Parses URIs and determines routing
 * @property CI_Session $session
 *      Session Class
 * @property CI_Encryption $encryption
 *      The Encryption Library provides two-way data encryption
 * @property CI_Table $table
 *      HTML table generation
 *      Lets you create tables manually or from database result objects, or arrays.
 * @property CI_Trackback $trackback
 *      Trackback Sending/Receiving Class
 * @property CI_Typography $typography
 *      Typography Class
 * @property CI_Unit_test $unit_test
 *      Simple testing class
 * @property MY_Upload $upload
 *      File Uploading Class
 * @property CI_URI $uri
 *      Parses URIs and determines routing
 * @property CI_User_agent $user_agent
 *      Identifies the platform, browser, robot, or mobile devise of the browsing agent
 * @property CI_Form_validation $validation
 * @property CI_Xmlrpc $xmlrpc
 *      XML-RPC request handler class
 * @property CI_Xmlrpcs $xmlrpcs
 *      XML-RPC server class
 * @property CI_Zip $zip
 *      Zip Compression Class
 * @property CI_Javascript $javascript
 *      Javascript Class
 * @property CI_Jquery $jquery
 *      Jquery Class
 * @property CI_Utf8 $utf8
 *      Provides support for UTF-8 environments
 * @property CI_Security $security
 *      Security Class, xss, csrf, etc...
 *
 * @property Chat_list_model chat_list_model
 * @property Course_model course_model
 * @property Message_model message_model
 * @property User_model user_model
 *
 * @property Canvas canvas
 * @property Header header
 *
 * @property string _result_object
 * @property string _table_name
 */
class MY_Model extends CI_Model
{
    protected $_result_object;
    protected $_table_name;

    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $thisName = $this->_getClassName();
        $thisNameNM = str_replace('_model', '', $thisName);
        $this->_table_name = plural(strtolower($thisNameNM));
        $this->_result_object = "\\Objects\\{$thisNameNM}";
    }

    /**
     * Compiles an array of select statements;
     *      the keys are the tableNames,
     *      values are arrays of select statements
     * @param array[] $tableSelect
     * @return array
     */
    protected function _compileSelect($tableSelect)
    {
        /**
         * Appends $tableName to the beginning of each element
         * @param string $tableName
         * @return Closure
         */
        $atn = function ($tableName) {
            return function ($val) use ($tableName) { return "{$tableName}.{$val}"; };
        };

        $select = array();
        foreach ($tableSelect as $tableName => $selectStatements)
            $select = array_merge($select, array_map(
                $atn($tableName), $selectStatements));
        return $select;
    }

    /**
     * Gets the array for a given conditional
     * @param array|string $where
     * @return array
     */
    protected function _getWhere($where = array())
    {
        $dbResult = $this->_getWhereDbResult($where);
        return (is_null($dbResult)) ? array() :
            $dbResult->result($this->_result_object);
    }

    /**
     * Gets the row for a given conditional
     * @param array|string $where
     * @return mixed
     */
    protected function _getWhereRow($where = array())
    {
        $dbResult = $this->_getWhereDbResult($where);
        return (is_null($dbResult)) ? null :
            $dbResult->row(0, $this->_result_object);
    }

    /**
     * Gets the array for a given conditional;
     *      allows caching of results
     * @param string $key
     * @param array $array
     * @param array $where
     * @return array
     */
    protected function _getCacheWhere($key, &$array, $where = array())
    {
        if (array_key_exists($key, $array)) {
            return $array[$key];
        } else {
            $result = $this->_getWhere($where);
            $array[$key] = $result;
            return $result;
        }
    }

    /**
     * Gets the row for a given conditional;
     *      allows caching of results
     * @param string $key
     * @param array $array
     * @param array $where
     * @return mixed
     */
    protected function _getCacheWhereRow($key, &$array, $where = array())
    {
        if (array_key_exists($key, $array)) {
            return $array[$key];
        } else {
            $result = $this->_getWhereRow($where);
            $array[$key] = $result;
            return $result;
        }
    }

    /**
     * Gets the name of the class, without the namespace
     * @return bool|string
     */
    private function _getClassName()
    {
        $className = get_class($this);
        if ($pos = strrpos($className, '\\'))
            return substr($className, $pos + 1);
        else return $className;
    }

    /**
     * Gets the DB_result for a given conditional;
     *      if a value is an array, uses where_in for that value;
     *          if that array is empty, returns null
     * @param array|string $where
     * @return CI_DB_result|null
     */
    private function _getWhereDbResult($where)
    {
        if (is_array($where)) {
            foreach ($where as $key => $value) {
                if (is_array($value)) {
                    if (count($value) > 0) {
                        $this->db->where_in($key, $value);
                        unset($where[$key]);
                    } else {
                        $this->db->reset_query();
                        return null;
                    }
                }
            }
        }

        return $this->db->get_where($this->_table_name, $where);
    }

    /**
     * Updates an element in the database if it exists;
     *      if not, creates it
     * @param Json_base $newEle
     */
    protected function _updateRow($newEle)
    {
        if (isset($newEle->id) && $newEle->id !== '') {
            $where = array('id' => $newEle->id);
            $dbEle = $this->_getWhereRow($where);
        } else $dbEle = $where = null;

        if (!is_null($dbEle)) {
            if (isset($newEle->json)) {
                $dbEleJson = (is_json($dbEle->json)) ? json_decode($dbEle->json, true) : array();
                $newEleJson = (is_json($newEle->json)) ? json_decode($newEle->json, true) : array();
                $newEle->set(array('json' => json_encode(array_merge($dbEleJson, $newEleJson))));
            }
            $this->db->update($this->_table_name, strip_non_class_values($newEle), $where);
        } else $this->db->insert($this->_table_name, strip_non_class_values($newEle));
    }

    /**
     * Updates elements in the database if they exist;
     *      if not, creates them
     * @param Json_base[] $newEles
     */
    protected function _updateRows($newEles)
    {
        $idEles = array_filter($newEles, function ($newEle) {
            return isset($newEle->id) && $newEle->id !== '';
        });
        $ids = array_map(function ($newEle) {
            return $newEle->id;
        }, $idEles);

        $where = array('id' => $ids);
        $dbEles = $this->_getWhere($where);

        $createBatch = array();
        $updateBatch = array();

        foreach ($newEles as $newEle) {
            $match = false;
            foreach ($dbEles as $dbEle) {
                if (isset($newEle->id) && $newEle->id !== '' &&
                    (string)$newEle->id === (string)$dbEle->id) {
                    $match = true;
                    if (isset($newEle->json)) {
                        $dbEleJson = (is_json($dbEle->json)) ? json_decode($dbEle->json, true) : array();
                        $newEleJson = (is_json($newEle->json)) ? json_decode($newEle->json, true) : array();
                        $newEle->set(array('json' => json_encode(array_merge($dbEleJson, $newEleJson))));
                    }
                    array_push($updateBatch, strip_non_class_values($newEle));
                    break;
                }
            }
            if (!$match) array_push($createBatch, $newEle);
        }

        // removes null values from the arrays
        $createBatch = array_filter($createBatch);
        $updateBatch = array_filter($updateBatch);

        if (count($createBatch) > 0)
            $this->db->insert_batch($this->_table_name, $createBatch);
        if (count($updateBatch) > 0)
            $this->db->update_batch($this->_table_name, $updateBatch, 'id');
    }
}
