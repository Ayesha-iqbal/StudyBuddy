<?php

/**
 * Custom Input class used primarily to implement put
 * Loosely based on:
 *      https://github.com/chriskacerguis/codeigniter-restserver/blob/master/application/libraries/REST_Controller.php
 * Class MY_Loader
 */
class MY_Input extends CI_Input
{
    /**
     * List of allowed HTTP methods
     *
     * @var array
     */
    protected $allowed_http_methods = ['delete', 'get', 'head', 'options', 'patch', 'post', 'put'];

    /**
     * Contains details about the request
     * Fields: body, format, method, ssl
     * Note: This is a dynamic object (stdClass)
     *
     * @var object
     */
    protected $request = NULL;

    /**
     * The arguments from GET, POST, PUT, DELETE, PATCH, HEAD and OPTIONS request methods combined
     *
     * @var array
     */
    protected $_args = array();
    /**
     * The arguments for the DELETE request method
     *
     * @var array
     */
    protected $_delete_args = array();
    /**
     * The arguments for the GET request method
     *
     * @var array
     */
    protected $_get_args = array();
    /**
     * The arguments for the HEAD request method
     *
     * @var array
     */
    protected $_head_args = array();
    /**
     * The arguments for the OPTIONS request method
     *
     * @var array
     */
    protected $_options_args = array();
    /**
     * The arguments for the PATCH request method
     *
     * @var array
     */
    protected $_patch_args = array();
    /**
     * The arguments for the POST request method
     *
     * @var array
     */
    protected $_post_args = array();
    /**
     * The arguments for the PUT request method
     *
     * @var array
     */
    protected $_put_args = array();
    /**
     * The arguments for the query parameters
     *
     * @var array
     */
    protected $_query_args = array();

    /**
     * List all supported methods, the first will be the default format
     *
     * @var array
     */
    protected $_supported_formats = [
        'json' => 'application/json',
        'array' => 'application/json',
        'csv' => 'application/csv',
        'html' => 'text/html',
        'jsonp' => 'application/javascript',
        'php' => 'text/plain',
        'serialized' => 'application/vnd.php.serialized',
        'xml' => 'application/xml'
    ];

    /**
     * MY_Input constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();

        // Initialise the response, request and rest objects
        $this->request = new stdClass();
        // Determine whether the connection is HTTPS
        $this->request->ssl = is_https();
        // How is this request being made? GET, POST, PATCH, DELETE, INSERT, PUT, HEAD or OPTIONS
        $this->request->method = $this->_detect_method();
        // Try to find a format for the request (means we have a request body)
        $this->request->format = $this->_detect_input_format();
        // Not all methods have a body attached with them
        $this->request->body = NULL;
        $this->{'_parse_' . $this->request->method}();

        //get header vars
        $this->_head_args = $this->request_headers();

        // Merge both for one mega-args variable
        $this->_args = array_merge(
            $this->_get_args,
            $this->_options_args,
            $this->_patch_args,
            $this->_head_args,
            $this->_put_args,
            $this->_post_args,
            $this->_delete_args,
            $this->{'_' . $this->request->method . '_args'}
        );
    }

    /**
     * Retrieve a value from a DELETE request
     *
     * @param mixed $index Index for item to be fetched from $this->_delete_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the DELETE request; otherwise, NULL
     */
    public function delete($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_delete_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from a GET request
     *
     * @param mixed $index Index for item to be fetched from $this->_get_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the GET request; otherwise, NULL
     */
    public function get($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_get_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from a HEAD request
     *
     * @param mixed $index Index for item to be fetched from $this->_head_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the HEAD request; otherwise, NULL
     */
    public function head($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_head_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from a OPTIONS request
     *
     * @param mixed $index Index for item to be fetched from $this->_options_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the OPTIONS request; otherwise, NULL
     */
    public function options($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_options_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from a PATCH request
     *
     * @param mixed $index Index for item to be fetched from $this->_patch_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the PATCH request; otherwise, NULL
     */
    public function patch($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_patch_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from a POST request
     *
     * @param mixed $index Index for item to be fetched from $this->_post_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the POST request; otherwise, NULL
     */
    public function post($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_post_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from a PUT request
     *
     * @param mixed $index Index for item to be fetched from $this->_put_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the PUT request; otherwise, NULL
     */
    public function put($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_put_args, $index, $xss_clean);
    }

    /**
     * Retrieve a value from the query parameters
     *
     * @param mixed $index Index for item to be fetched from $this->_query_args
     * @param bool $xss_clean Whether to apply XSS filtering
     * @return array|string|NULL Value from the query parameters; otherwise, NULL
     */
    public function query($index = NULL, $xss_clean = NULL)
    {
        return $this->_fetch_from_array($this->_query_args, $index, $xss_clean);
    }

    /**
     * Get the input format e.g. json or xml
     *
     * @return string|NULL Supported input format; otherwise, NULL
     */
    protected function _detect_input_format()
    {
        // Get the CONTENT-TYPE value from the SERVER variable
        $content_type = $this->server('CONTENT_TYPE');
        if (empty($content_type) === FALSE) {
            // If a semi-colon exists in the string, then explode by ; and get the value of where
            // the current array pointer resides. This will generally be the first element of the array
            $content_type = ((strpos($content_type, ';') !== FALSE) ?
                current(explode(';', $content_type)) : $content_type);
            // Check all formats against the CONTENT-TYPE header
            foreach ($this->_supported_formats as $type => $mime) {
                // $type = format e.g. csv
                // $mime = mime type e.g. application/csv
                // If both the mime types match, then return the format
                if ($content_type === $mime) {
                    return $type;
                }
            }
        }
        return NULL;
    }

    /**
     * Get the HTTP request string e.g. get or post
     *
     * @access protected
     * @return string|NULL Supported request method as a lowercase string; otherwise, NULL if not supported
     */
    protected function _detect_method()
    {
        // Declare a variable to store the method
        $method = NULL;
        // todo use config instead
        $enable_emulate_request = TRUE;
        // $enable_emulate_request = config_item('enable_emulate_request')
        if ($enable_emulate_request === TRUE) {
            $method = $this->post('_method');
            if ($method === NULL) {
                $method = $this->server('HTTP_X_HTTP_METHOD_OVERRIDE');
            }
            $method = strtolower($method);
        }
        if (empty($method)) {
            // Get the request method as a lowercase string
            $method = $this->method();
        }

        $isAllowed = in_array($method, $this->allowed_http_methods);
        $parseExists = method_exists($this, '_parse_' . $method);

        return ($isAllowed && $parseExists) ? $method : 'get';
    }

    /**
     * Parse the DELETE request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_delete()
    {
        // These should exist if a DELETE request
        if ($this->method() === 'delete') {
            $this->_delete_args = $this->input_stream();
        }
    }

    /**
     * Parse the GET request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_get()
    {
        $this->_get_args = $_GET;
    }

    /**
     * Parse the HEAD request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_head()
    {
        // Parse the HEAD variables
        parse_str(parse_url($this->server('REQUEST_URI'), PHP_URL_QUERY), $head);

        // Merge both the URI segments and HEAD params
        $this->_head_args = array_merge($this->_head_args, $head);
    }

    /**
     * Parse the OPTIONS request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_options()
    {
        // Parse the OPTIONS variables
        parse_str(parse_url($this->server('REQUEST_URI'), PHP_URL_QUERY), $options);

        // Merge both the URI segments and OPTIONS params
        $this->_options_args = array_merge($this->_options_args, $options);
    }

    /**
     * Parse the PATCH request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_patch()
    {
        // It might be a HTTP body
        if ($this->request->format) {
            $this->request->body = $this->raw_input_stream;
        } else if ($this->method() === 'patch') {
            // If no file type is provided, then there are probably just arguments
            $this->_patch_args = $this->input_stream();
        }
    }

    /**
     * Parse the POST request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_post()
    {
        $this->_post_args = $_POST;

        if ($this->request->format) {
            $this->request->body = $this->raw_input_stream;
            if ($this->request->format === 'json') {
                $this->_post_args = json_decode($this->raw_input_stream, true);
            }
        }
    }

    /**
     * Parse the PUT request arguments
     *
     * @access protected
     * @return void
     */
    protected function _parse_put()
    {
        if ($this->request->format) {
            $this->request->body = $this->raw_input_stream;
            if ($this->request->format === 'json') {
                $this->_put_args = json_decode($this->raw_input_stream, true);
            }
        } else if ($this->method() === 'put') {
            // If no file type is provided, then there are probably just arguments
            $this->_put_args = $this->input_stream();
        }
    }

    /**
     * Parse the query parameters
     *
     * @access protected
     * @return void
     */
    protected function _parse_query()
    {
        $this->_query_args = $this->get();
    }
}