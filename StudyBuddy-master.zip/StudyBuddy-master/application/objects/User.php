<?php namespace Objects;

/**
 * Class User
 * @package Objects
 */
class User extends Json_base
{
    /** @var string varchar 255 */
    public $name;
    /** @var string varchar 255 */
    public $short_name;
    /** @var string varchar 255 */
    public $sortable_name;
}