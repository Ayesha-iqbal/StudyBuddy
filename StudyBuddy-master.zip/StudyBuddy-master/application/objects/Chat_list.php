<?php namespace Objects;

/**
 * Class Chat_list
 * @package Objects
 *
 * join variables
 * @property int $from
 * @property string $user_name
 * @property string $group_name
 * @property string $message
 * @property string $status
 * @property double $timestamp
 * @property string $media_type
 */
class Chat_list extends Json_base
{
    /** @var int unsigned */
    public $message_id;
    /** @var int unsigned */
    public $user_id;

    /**
     * @var int|null unsigned
     * id of the receiver
     */
    public $to;
    /**
     * @var int|null unsigned
     * id of the receiving group
     */
    public $to_group;
}