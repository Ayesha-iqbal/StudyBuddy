<?php namespace Objects;

/**
 * Class Message
 * @package Objects
 */
class Message extends Json_base
{
    /**
     * @var int unsigned
     * id of the sender
     */
    public $from;
    /**
     * @var int|null unsigned
     * id of the receiver
     */
    public $to;
    /**
     * @var int|null unsigned
     * id of the receiving group
     */
    public $to_group;
    /**
     * @var string char 1
     * message status: '0' = deleted, '1' = sent, '2' = received, '6' = control message
     */
    public $status;
    /**
     * @var double unsigned decimal 14, 4
     * unix timestamp with microseconds
     */
    public $timestamp;

    /**
     * @var string char 1
     * message type: '0' = text, '1' = image,
     *  '2' = audio, '3' = video, '4' = pdf, '5' = other
     */
    public $media_type;
    /**
     * @var string text $data
     * message content when media_type = '0'
     */
    public $data;
    /**
     * @var string|null varchar 127
     * url slug of the transmitted file (when media_type > 0)
     */
    public $media_url;
    /**
     * @var double|null unsigned decimal 9, 2
     * approximate size in kilobytes of the transmitted file (when media_type > 0)
     */
    public $media_size;
    /**
     * @var string|null varchar 127
     * display name of transmitted file (when media_type > 0)
     */
    public $media_name;

}