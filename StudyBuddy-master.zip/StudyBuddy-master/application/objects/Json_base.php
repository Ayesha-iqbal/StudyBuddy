<?php namespace Objects;

/**
 * Class Json_base
 * @package Objects
 */
class Json_base extends A_base
{
    /** @var int unsigned */
    public $id;
    /** @var string text */
    public $json;
}