<?php namespace Objects;

/**
 * Class A_base;
 *      StudyBuddies base object
 * @package Objects
 */
class A_base
{
    public function __construct($constructArray = array()) { $this->set($constructArray); }

    public function set($constructArray)
    {
        foreach ($constructArray as $key => $value)
            $this->$key = $value;
        return $this;
    }

    public function __toString() { return json_encode($this); }
}