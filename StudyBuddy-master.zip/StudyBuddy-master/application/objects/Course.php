<?php namespace Objects;

/**
 * Class Course
 * @package Objects
 */
class Course extends Json_base
{
    /** @var string varchar 255 */
    public $course_code;
    /** @var string varchar 255 */
    public $name;

    /** @var string varchar 255 */
    public $start_at;
    /** @var string varchar 255 */
    public $end_at;

    /** @var string text */
    public $enrolled_students;
}