<?php

use \Objects\Course;
use \Objects\User;

class Dashboard extends MY_Controller
{
    public function _remap($method, $params = array())
    {
        if (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
            if ($this->input->get('profiler') == 1)
                $this->output->enable_profiler(true);
        } else show_404();
    }

    /**
     * View Methods
     */

    public function index()
    {
        $this->load->model(array('course_model', 'user_model'));

        $studentId = +$this->session->userdata('studentId');
        $student = $this->user_model->getUser(array('id' => $studentId));

        if (!is_null($student)) {
            $courses = $this->course_model->getCoursesCurrent(
            /** @lang SQL */ "`enrolled_students` LIKE '%{$studentId}%' ESCAPE '!'");
        } else $courses = array();

        $this->load->view('header', $this->header->dashboard__index());
        $this->load->view('header-bar', $this->header->headerBar['default']);
        $this->load->view('courses', array(
            'courses' => $courses, 'student' => $student));
        $this->load->view('footer');
    }

    public function student($studentId = null)
    {
        $this->load->model(array('course_model', 'user_model'));

        $selfId = +$this->session->userdata('studentId');
        $redirect = $this->session->flashdata('redirect') ?? 'dashboard/courses';
        $student = $this->user_model->getUser(array('id' => $studentId));
        if (is_null($student)) redirect($redirect);

        $courses = $this->course_model->getCourses(array(
            /** @lang SQL */ "`enrolled_students` LIKE '%{$studentId}%' ESCAPE '!'" => null,
            /** @lang SQL */ "`enrolled_students` LIKE '%{$selfId}%' ESCAPE '!'" => null));
        $currentCourses = $this->course_model->filterCurrent($courses);
        $previousCourses = $this->course_model->filterPrevious($courses);

        $this->load->view('header', $this->header->dashboard__student($student->name));
        $this->load->view('header-bar', $this->header->headerBar['default']);
        $this->load->view('student', array(
            'currentCourses' => $currentCourses,
            'previousCourses' => $previousCourses,
            'student' => $student));
        $this->load->view('footer');
    }

    public function course($courseId = null, $filter = '')
    {
        $this->load->model(array('course_model', 'user_model'));

        $course = $this->course_model->getCourse(array('id' => $courseId));
        if (is_null($course)) redirect('dashboard/courses');

        $this->session->set_flashdata('redirect',
            "dashboard/course/{$courseId}/{$filter}");

        $studentId = +$this->session->userdata('studentId');
        $studentIds = json_decode($course->enrolled_students, true);
        // remove self from array
        $studentIds = array_diff($studentIds, array($studentId));
        $students = $this->user_model->getUsers(array('id' => $studentIds));

        if ($filter === 'multiple' || $filter === 'previous') {
            $where = /** @lang SQL */
                "`enrolled_students` LIKE '%{$studentId}%' ESCAPE '!'";
            $courses = ($filter === 'multiple') ?
                $this->course_model->getCoursesCurrent($where) :
                $this->course_model->getCoursesPrevious($where);

            // ensures that the current course is always included in courses
            if (!in_array($course, $courses))
                $courses = array_merge($courses, array($course));

            $occurrences = $this->_getOccurrences($courses);
            $students = array_filter($students, function ($student) use ($occurrences) {
                return ($occurrences[$student->id] ?? 0) > 1;
            });
            usort($students, function ($a, $b) use ($occurrences) {
                if ($occurrences[$a->id] !== $occurrences[$b->id])
                    return $occurrences[$b->id] - $occurrences[$a->id];
                else return strcmp($a->sortable_name, $b->sortable_name);
            });
        }

        $this->load->view('header', $this->header->dashboard__course($course->name));
        $this->load->view('header-bar', $this->header->headerBar['default']);
        $this->load->view('course', array(
            'course' => $course,
            'filter' => $filter,
            'students' => $students,
            'occurrences' => $occurrences ?? array(),
        ));
        $this->load->view('footer');
    }

    public function courses() { redirect('dashboard'); }

    public function login()
    {
        $this->load->view('header', $this->header->dashboard__login());
        $this->load->view('header-bar', $this->header->headerBar['default']);
        $this->load->view('login');
        $this->load->view('footer');
    }

    /**
     * Action Methods
     */

    /**
     * Attempts to log the user in;
     *      redirects to login on failure;
     *      redirects to dashboard on success;
     */
    public function loginSubmit()
    {
        $this->load->model('user_model');

        $canvasToken = $this->input->get('canvasToken');
        if (isset($canvasToken))
            $this->session->set_userdata('canvasToken', $canvasToken);

        // load canvas library after setting 'canvasToken' userdata
        $this->load->library('canvas');

        $userProfile = $this->canvas->getUserProfile();

        if (isset($userProfile['errors'])) {
            foreach ($userProfile['errors'] as $error)
                $this->session->set_flashdata('errorMessage', $error['message']);
            redirect('dashboard/login');
        }

        $this->session->set_userdata('studentId', $userProfile['id']);
        $this->user_model->updateUser(new User(array(
            'id' => $userProfile['id'],
            'json' => json_encode($userProfile),

            'name' => $userProfile['name'],
            'short_name' => $userProfile['short_name'],
            'sortable_name' => $userProfile['sortable_name'],
        )));

        redirect('dashboard');
    }

    /**
     * Logs the user out;
     *      redirects to login page
     */
    public function logout()
    {
        $this->session->unset_userdata(array(
            'canvasToken', 'studentId', 'courses_updated_at', 'students_updated_at'));
        $this->session->set_flashdata('successMessage', 'You have been successfully logged out.');
        redirect('dashboard/login');
    }

    /**
     * Private Methods
     */

    /**
     * Tallies occurrences of each student
     *      in an array of courses
     * @param Course[] $courses
     * @return array
     */
    private function _getOccurrences($courses)
    {
        $occurrences = array();

        foreach ($courses as $course) {
            $studentIds = json_decode($course->enrolled_students, true);
            foreach ($studentIds as $sid) {
                if (!isset($occurrences[$sid]))
                    $occurrences[$sid] = 0;
                $occurrences[$sid]++;
            }
        }

        return $occurrences;
    }
}
