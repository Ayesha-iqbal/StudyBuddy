<?php

use \Objects\Course;
use \Objects\User;

class Api extends MY_Controller
{
    const SECONDS_IN_DAY = 86400;

    public function _remap($method, $params = array())
    {
        if (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
            $this->session->keep_flashdata(array('redirect'));
        } else show_404();
    }

    /**
     * View Methods
     */

    /**
     * Action Methods
     */

    public function courses()
    {
        $this->load->library('canvas');
        $this->load->model('course_model');

        $courses_updated_at = $this->session->userdata('courses_updated_at');
        if (!is_null($courses_updated_at)) {
            $coursesUpdatedAt = strtotime($courses_updated_at);
            if (time() < $coursesUpdatedAt + $this::SECONDS_IN_DAY) return;
        }

        $courses = $this->canvas->getCourses();
        $studentId = +$this->session->userdata('studentId');

        if (!isset($courses['errors'])) {
            $courses = array_filter($courses, function ($course) {
                // course has a name and it's fresh
                return isset($course['name']) &&
                    strtotime($course['end_at']) >= time();
            });

            /** @var Course[] $dbCourses */
            $dbCourses = array();
            $dbCoursesUnsorted = $this->course_model->getCourses(
            /** @lang SQL */ "`enrolled_students` LIKE '%{$studentId}%' ESCAPE '!'");
            foreach ($dbCoursesUnsorted as $dbCourse)
                $dbCourses[$dbCourse->id] = $dbCourse;

            $courseObjs = array_map(function ($course) use ($dbCourses, $studentId) {
                $dbCourse = $dbCourses[$course['id']] ?? null;
                if (!is_null($dbCourse)) {
                    $enrolledStudents = json_decode($dbCourse->enrolled_students, true);
                    $enrolledStudents[] = $studentId;
                    $enrolledStudents = array_unique($enrolledStudents);
                    $enrolledStudents = array_values($enrolledStudents);
                } else $enrolledStudents = array($studentId);

                return new Course(array(
                    'id' => $course['id'],
                    'json' => json_encode($course),

                    'course_code' => $course['course_code'],
                    'name' => $course['name'],
                    'start_at' => $course['start_at'],
                    'end_at' => $course['end_at'],

                    'enrolled_students' => json_encode($enrolledStudents),
                ));
            }, $courses);
            $courseObjs = array_unique($courseObjs);
            $this->course_model->updateCourses($courseObjs);

            if (count($courseObjs) > 0)
                $this->session->set_userdata('courses_updated_at', date('Y-m-d\TH:i:s\Z'));
        }
    }

    public function students()
    {
        $this->load->library('canvas');
        $this->load->model(array('course_model', 'user_model'));

        $students_updated_at = $this->session->userdata('students_updated_at');
        if (!is_null($students_updated_at)) {
            $studentsUpdatedAt = strtotime($students_updated_at);
            if (time() < $studentsUpdatedAt + $this::SECONDS_IN_DAY) return;
        }

        $studentId = +$this->session->userdata('studentId');
        $dbCourses = $this->course_model->getCoursesCurrent(
        /** @lang SQL */ "`enrolled_students` LIKE '%{$studentId}%' ESCAPE '!'");

        foreach ($dbCourses as $dbCourse) {
            $students = $this->canvas->getStudents($dbCourse->id);
            if (!isset($students['errors'])) {
                $userObjs = array_map(function ($student) {
                    return new User(array(
                        'id' => $student['id'],
                        'json' => json_encode($student),

                        'name' => $student['name'],
                        'short_name' => $student['short_name'],
                        'sortable_name' => $student['sortable_name'],
                    ));
                }, $students);
                $userObjs = array_unique($userObjs);
                $this->user_model->updateUsers($userObjs);

                $enrolledStudents = array_map(function ($userObj) { return $userObj->id; }, $userObjs);
                $dbCourse->set(array('enrolled_students' => json_encode($enrolledStudents)));

                if (count($enrolledStudents) > 0)
                    $this->session->set_userdata('students_updated_at', date('Y-m-d\TH:i:s\Z'));
            }
        }

        $this->course_model->updateCourses($dbCourses);
    }
}
