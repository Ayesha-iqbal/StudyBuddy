<?php

use \Objects\Chat_list;
use \Objects\Message;

class Messenger extends MY_Controller
{
    public function _remap($method, $params = array())
    {
        if (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
            if ($this->input->get('profiler') == 1)
                $this->output->enable_profiler(true);
        } else show_404();
    }

    /**
     * View Methods
     */

    public function index()
    {
        $this->load->model('chat_list_model');

        $chatLists = $this->chat_list_model->getUserChatLists();

        $this->load->view('header', $this->header->messenger__index());
        $this->load->view('header-bar', $this->header->headerBar['default']);
        $this->load->view('msg/messenger', array('chatLists' => $chatLists));
    }

    public function g($gid = null) { $this->_chatWith('g', $gid); }

    public function s($sid = null) { $this->_chatWith('s', $sid); }

    /**
     * Action Methods
     */

    /**
     * Gets 30 older messages;
     *      in addition, gets the newer messages to redraw all
     */
    public function get_older()
    {
        $this->load->model('message_model');

        $this->_getMessages($this->input->get(),
            function ($method, $id, $studentId, $messageOffset) {
                if ($method === 's') {
                    $oldMessages = $this->message_model->getUserMessages(
                        $id, $messageOffset + 30, 0);
                } else {
                    // todo(2019-12-01): groups messages!
                    $oldMessages = array();
                }

                $messagesHtml = $this->load->view('msg/messages', array(
                    'messages' => $oldMessages,
                    'studentId' => $studentId,
                ), true);
                echo json_encode(array('messages' => $messagesHtml));
            });
    }

    /**
     * Gets newer (unread) messages;
     *      in addition, gets the older messages to redraw all;
     *      marks messages as read upon retrieval;
     * todo(2019-12-02): this may cause messages to always appear as read when not in messenger...
     */
    public function get_newer()
    {
        $this->load->model('message_model');

        $this->_getMessages($this->input->get(),
            function ($method, $id, $studentId, $messageOffset) {
                if ($method === 's') {
                    $newMessages = $this->message_model->getNewUserMessages($id);
                    if (count($newMessages) > 0) {
                        foreach ($newMessages as &$message)
                            if ($message->status === '1' && +$message->to === +$studentId)
                                $message->status = '2';
                        $this->message_model->updateMessages($newMessages);

                        $messages = $this->message_model->getUserMessages(
                            $id, $messageOffset + count($newMessages), 0);
                    } else $messages = array();
                } else {
                    // todo(2019-12-01): groups messages!
                    $newMessages = $messages = array();
                }

                if (count($newMessages) > 0) {
                    $messagesHtml = $this->load->view('msg/messages', array(
                        'messages' => $messages,
                        'studentId' => $studentId,
                    ), true);
                } else $messagesHtml = '';

                echo json_encode(array('messages' => $messagesHtml));
            });
    }

    /**
     * Gets the chat lists in order to repaint
     */
    public function get_chats()
    {
        $this->load->model(array('chat_list_model', 'message_model'));

        $this->_getMessages($this->input->get(),
            function ($method, $id) {
                $chatLists = $this->chat_list_model->getUserChatLists();

                $chatListsHtml = $this->load->view('msg/chat-lists', array(
                    'chatLists' => $chatLists,
                    'chatSelected' => "{$method}/{$id}",
                ), true);
                echo json_encode(array('chatLists' => $chatListsHtml));
            });
    }

    /**
     * Gets number of newer (unread) messages;
     *      gets unread messages for current chat,
     *      as well as all unread messages,
     */
    public function get_newer_count()
    {
        $this->load->model('message_model');

        $this->_getMessages($this->input->get(),
            function ($method, $id, $studentId, $messageOffset) {
                $allNewGroupMessages = array();
                $allNewUserMessages = $this->message_model->getNewUserMessages();
                if ($method === 's') {
                    $chatNewMessages = $this->message_model->getNewUserMessages($id);
                } else if ($method === 'g') {
                    // todo(2019-12-01): groups messages!
                    $chatNewMessages = array();
                } else $chatNewMessages = array();

                $allNewMessages = array_merge($allNewGroupMessages, $allNewUserMessages);

                echo json_encode(array(
                    'all' => count($allNewMessages) - count($chatNewMessages),
                    'chat' => count($chatNewMessages)));
            });
    }

    /**
     * Sends a message to another user or group;
     *      also sends a file if applicable
     */
    public function send_message()
    {
        $this->load->model(array('chat_list_model', 'message_model'));

        $this->_getMessages($this->input->post(),
            function ($method, $id, $studentId, $messageOffset) {
                $messageBase = array(
                    'json' => '',
                    'from' => $studentId,
                    'to' => ($method === 's') ? $id : null,
                    'to_group' => ($method === 'g') ? $id : null,
                    'status' => '1');

                $messages = array();

                if (isset($_FILES['userFile'])) {
                    $this->load->helper('file');
                    $this->load->library('upload');

                    $uploadPath = 'assets/uploads';
                    $uploadMaxSizeMB = $this->upload->get_max_upload_bytes() * 1024;

                    $config['file_name'] = guid();
                    $config['upload_path'] = "./{$uploadPath}";
                    $config['allowed_types'] = '*';
                    $config['max_size'] = $uploadMaxSizeMB;
                    $this->upload->initialize($config);

                    if ($this->upload->do_upload('userFile')) {
                        $uData = $this->upload->data();

                        $mediaTypeInt = '5';
                        $mime = get_mime_by_extension($uData['file_ext']);
                        $mediaTypes = array('1' => 'image', '2' => 'audio', '3' => 'video', '4' => 'application/pdf');

                        foreach ($mediaTypes as $int => $mediaCheck)
                            if (starts_with($mime, $mediaCheck))
                                $mediaTypeInt = $int;

                        $messages[] = new Message(array_merge($messageBase, array(
                            'timestamp' => microtime(true),

                            'media_type' => $mediaTypeInt,
                            'media_url' => base_url("{$uploadPath}/{$uData['file_name']}"),
                            'media_size' => $uData['file_size'],
                            'media_name' => $uData['client_name'],
                        )));
                    }
                }

                $userMessage = $this->input->post('userMessage');
                if (!is_null($userMessage)) {
                    $messages[] = new Message(array_merge($messageBase, array(
                        // ensure this message arrives after the other
                        'timestamp' => microtime(true) + .0001,
                        'media_type' => '0',
                        'data' => $userMessage,
                    )));
                }

                $this->message_model->updateMessages($messages);

                //region updating chat lists
                $messages = $this->message_model->getUserMessages($id, count($messages), 0);
                $lastMessage = reset($messages);
                if ($lastMessage !== false) {
                    /** @var Message $lastMessage */
                    // todo(2019-12-03): handling for groups
                    if (!is_null($lastMessage->to)) {
                        $cl = 'chat_lists';
                        $clTo = "`{$cl}`.`to`";
                        $clUserId = "`{$cl}`.`user_id`";

                        $where = "({$clUserId} = {$lastMessage->from} AND {$clTo} = {$lastMessage->to}) OR ({$clUserId} = {$lastMessage->to} AND {$clTo} = {$lastMessage->from})";
                        $chatLists = $this->chat_list_model->getChatLists($where);

                        $hasTo = false;
                        $hasFrom = false;
                        foreach ($chatLists as &$chatList) {
                            if ($chatList->user_id === $lastMessage->to) $hasTo = true;
                            if ($chatList->user_id === $lastMessage->from) $hasFrom = true;
                            $chatList->message_id = $lastMessage->id;
                        }

                        if (!$hasTo) $chatLists[] = new Chat_list(array(
                            'message_id' => $lastMessage->id,
                            'user_id' => $lastMessage->to,
                            'to' => $lastMessage->from,
                        ));
                        if (!$hasFrom) $chatLists[] = new Chat_list(array(
                            'message_id' => $lastMessage->id,
                            'user_id' => $lastMessage->from,
                            'to' => $lastMessage->to,
                        ));

                        $this->chat_list_model->updateChatLists($chatLists);
                    }
                }
                //endregion

                $chatLists = $this->chat_list_model->getUserChatLists();
                if ($method === 's') {
                    $newMessages = $this->message_model->getUserMessages(
                        $id, $messageOffset + count($messages), 0);
                } else {
                    // todo(2019-12-01): groups messages!
                    $newMessages = array();
                }

                $chatListsHtml = $this->load->view('msg/chat-lists', array(
                    'chatLists' => $chatLists,
                    'chatSelected' => "{$method}/{$id}",
                ), true);
                $messagesHtml = $this->load->view('msg/messages', array(
                    'messages' => $newMessages,
                    'studentId' => $studentId,
                ), true);
                echo json_encode(array('chatLists' => $chatListsHtml, 'messages' => $messagesHtml));
            });
    }

    /**
     * Private Methods
     */

    /**
     * Opens up the messenger to chat with the specified user or group
     * @param string $method
     * @param string|null $id
     */
    private function _chatWith($method = 's', $id = null)
    {
        $this->load->model(array('chat_list_model', 'message_model', 'user_model'));

        if (is_null($id)) {
            $chatLists = $this->chat_list_model->getUserChatLists();
            $chatList = reset($chatLists);

            if ($chatList !== false) {
                if (!is_null($gid = $chatList->to_group)) redirect("messenger/g/{$gid}");
                if (!is_null($sid = $chatList->to)) redirect("messenger/s/{$sid}");
            }
        }

        $studentId = +$this->session->userdata('studentId');

        if ($method === 's') {
            $messages = $this->message_model->getUserMessages($id, 20, 0);
            foreach ($messages as &$message)
                if ($message->status === '1' && +$message->to === +$studentId)
                    $message->status = '2';
            $this->message_model->updateMessages($messages);
        } else {
            // todo(2019-12-01): groups messages!
            // todo(2019-12-02): how to mark group messages as read for each user?? maybe in json?
            $messages = array();
        }

        $chatLists = $this->chat_list_model->getUserChatLists();

        //region adding temporary chat list for new message
        $currentChatSet = false;
        foreach ($chatLists as $chatList) {
            if ($method === 's') {
                if ($chatList->to === $id)
                    $currentChatSet = true;
            } else {
                if ($chatList->to_group === $id)
                    $currentChatSet = true;
            }
        }

        if (!$currentChatSet && !is_null($id)) {
            $chatListArgs = array('user_id' => (string)$studentId);
            if ($method === 's') {
                $user = $this->user_model->getUser(array('id' => $id));
                $chatListArgs['to'] = $id;
                $chatListArgs['user_name'] = $user->name;
            } else {
                $chatListArgs['to_group'] = $id;
            }

            array_unshift($chatLists, new Chat_list($chatListArgs));
        }
        //endregion

        $this->load->view('header', $this->header->messenger__index());
        $this->load->view('header-bar', $this->header->headerBar['default']);
        $this->load->view('msg/messenger', array(
            'chatLists' => $chatLists,
            'chatSelected' => "{$method}/{$id}",
            'messages' => $messages,
            'studentId' => $studentId));
    }

    /**
     * Applies a callback function;
     *      uses $method, $id, $studentId, $messageOffset
     * @param array $getPost
     * @param closure $callback
     */
    private function _getMessages($getPost, $callback)
    {
        $studentId = +$this->session->userdata('studentId');

        $chatProps = explode('/', $getPost['chatSelected'] ?? '');
        $method = $chatProps[0] ?? null;
        $id = $chatProps[1] ?? null;
        $messageOffset = +($getPost['messageOffset'] ?? 0);

        $callback($method, $id, $studentId, $messageOffset);
    }
}
