<?php use \Objects\Course;

/** @var Course[] $courses */
$courses = $courses ?? array();

$sM = 6;
$sL = 4;
$offsetM = (12 - count($courses) * $sM) / 2;
$offsetL = (12 - count($courses) * $sL) / 2;
$i = 0;

$icons = array(
    'CS' => 'fas fa-file-code',
    'CMPE' => 'fas fa-desktop',
    'ENGR' => 'fas fa-cogs',
    'ISE' => 'fas fa-tools',
    'KIN' => 'fas fa-dumbbell',
    'MATH' => 'fas fa-square-root-alt',
); ?>
<div class="grid-x grid-margin-x">
    <?php foreach ($courses as $course) {
        $firstOffsetM = ($offsetM > 0 && $i === 0) ? "medium-offset-{$offsetM}" : '';
        $firstOffsetL = ($offsetL > 0 && $i === 0) ? "large-offset-{$offsetL}" : '';
        $cellSizing = "cell {$firstOffsetM} medium-{$sM} {$firstOffsetL} large-{$sL}";
        $cClasses = "callout {$cellSizing} text-center courses__callout";

        $cLink = base_url("dashboard/course/{$course->id}");

        $cInner = '';
        $names = explode(' - ', $course->name);
        foreach ($icons as $code => $iconClass)
            if (strpos($names[0], $code) !== false)
                $cInner .= "<i class='{$iconClass} courses__icon'></i><br>";
        $cInner .= join('<br>', $names);

        echo "<a class='{$cClasses}' href='{$cLink}'>{$cInner}</a>";

        $i++;
    } ?>
</div>