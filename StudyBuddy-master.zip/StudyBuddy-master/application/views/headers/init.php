<script src="<?= javascripts_url('init.js') ?>"></script>
