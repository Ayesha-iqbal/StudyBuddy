<script src="<?= javascripts_url('lib/jquery.js') ?>"></script>
<script src="<?= javascripts_url('lib/jquery.ba-throttle-debounce.js') ?>"></script>
<script src="<?= javascripts_url('lib/gsap.js') ?>"></script>
<script src="<?= javascripts_url('lib/CSSRulePlugin.js') ?>"></script>
<script src="<?= javascripts_url('lib/what-input.js') ?>"></script>
<script src="<?= javascripts_url('lib/polyfill.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.core.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.util.mediaQuery.js') ?>"></script>
