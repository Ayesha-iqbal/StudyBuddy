<script src="<?= javascripts_url('lib/foundation.util.imageLoader.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.util.keyboard.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.util.motion.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.util.timer.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.util.touch.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.util.triggers.js') ?>"></script>

<script src="<?= javascripts_url('lib/foundation.smoothScroll.js') ?>"></script>

<script src="<?= javascripts_url('lib/foundation.interchange.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.magellan.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.orbit.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.sticky.js') ?>"></script>
<script src="<?= javascripts_url('lib/foundation.toggler.js') ?>"></script>

<script src="<?= javascripts_url('study-buddies.js') ?>"></script>


<link rel="stylesheet" href="<?= stylesheets_url('app.css') ?>">
<link rel="stylesheet" href="<?= stylesheets_url('study-buddies.css') ?>">
<link rel="stylesheet" href="<?= stylesheets_url('fontawesome.css') ?>">
<link rel="stylesheet" href="<?= stylesheets_url('fa-solid.css') ?>">
