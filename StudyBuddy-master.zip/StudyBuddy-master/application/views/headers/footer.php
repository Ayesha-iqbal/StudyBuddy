<link rel="stylesheet" href="<?= stylesheets_url('footer.css') ?>">
