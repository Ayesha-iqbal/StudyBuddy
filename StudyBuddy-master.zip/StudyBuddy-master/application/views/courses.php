<?php /** @var MY_Loader $this */

use \Objects\Course;
use \Objects\User;

/** @var Course[] $courses */
$courses = $courses ?? array();
/** @var User $student */
$student = $student ?? null;

if (!is_null($student)) {
    $names = explode(' ', $student->name);
    $welcomeMessage = "Welcome to StudyBuddies, {$names[0]}!";
} else $welcomeMessage = 'Welcome to StudyBuddies!';

$hr = (count($courses)) ? '<hr>' : ''; ?>
<div class="grid-x grid-padding-x courses">
    <div class="cell medium-offset-1 medium-10">
        <?= "<h1 class='font-bold text-center'>{$welcomeMessage}</h1>{$hr}"; ?>
        <?php $this->CI->load->view('courses-grid', array('courses' => $courses)); ?>
    </div>
</div>

