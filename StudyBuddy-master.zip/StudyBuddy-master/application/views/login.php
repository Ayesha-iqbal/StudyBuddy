<?php /** @var MY_Loader $this */ ?>
<div class="grid-x grid-padding-x login">
    <div class="cell medium-offset-3 medium-6 large-offset-4 large-4">
        <form class="form" action="<?= base_url('dashboard/loginSubmit'); ?>">
            <h4 class="heading">Login</h4>
            <label for="canvasToken">Canvas Token:</label>
            <input class="login__input" id="canvasToken"
                   type="text" name="canvasToken" required>
            <?php $successMessage = $this->CI->session->flashdata('successMessage');
            if (isset($successMessage)): ?>
                <div class="successMessage heading">
                    <?= $successMessage; ?>
                </div>
            <?php endif;
            $errorMessage = $this->CI->session->flashdata('errorMessage');
            if (isset($errorMessage)): ?>
                <div class="errorMessage heading">
                    <?= $errorMessage; ?>
                </div>
            <?php endif; ?>
            <button class="button primary login__button" type="submit">Submit</button>
        </form>
    </div>
</div>
