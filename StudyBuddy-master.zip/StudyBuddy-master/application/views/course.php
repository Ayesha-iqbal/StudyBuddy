<?php

use \Objects\Course;
use \Objects\User;

/** @var Course $course */
$course = $course ?? null;
$filter = $filter ?? '';
$occurrences = $occurrences ?? array();
/** @var User[] $students */
$students = $students ?? array();

$appearsIn = array(
    '' => 'This Class',
    'multiple' => 'Multiple Classes',
    'previous' => 'Previous Classes');
if (!isset($appearsIn[$filter])) $filter = '';

if (count($students)) {
    $splitStudents3 = array_chunk($students, ceil(count($students) / 3));
    $splitStudents4 = array_chunk($students, ceil(count($students) / 4));
} else $splitStudents3 = $splitStudents4 = array(); ?>
<div class="grid-x grid-padding-x padding-horizontal-1">
    <div class="cell">
        <?= "<h1 class='h3 text-center margin-top-1'>{$course->name}</h1><hr>"; ?>
    </div>
    <div class="cell text-center">
        <span>Appears in:&nbsp;</span>
        <?php foreach ($appearsIn as $linkSlug => $label) {
            $selected = ($filter === $linkSlug) ? 'secondary' : '';
            $link = base_url("dashboard/course/{$course->id}/{$linkSlug}");
            echo "<a class='button courses__button {$selected}' href='{$link}'>{$label}</a>&nbsp;";
        } ?>
        <hr>
    </div>
    <?php $printUserGroup = function ($studentGroup) use ($occurrences) {
        foreach ($studentGroup as $student) {
            $studentLink = base_url("dashboard/student/{$student->id}");
            if (isset($occurrences[$student->id])) {
                echo "<li><a href='{$studentLink}'>{$occurrences[$student->id]} - {$student->name}</a></li>";
            } else {
                echo "<li><a href='{$studentLink}'>{$student->name}</a></li>";
            }
        }
    };
    foreach ($splitStudents4 as $studentGroup): ?>
        <div class="cell large-3 show-for-large ">
            <ul><?php $printUserGroup($studentGroup); ?></ul>
        </div>
    <?php endforeach;
    foreach ($splitStudents3 as $studentGroup): ?>
        <div class="cell medium-4 hide-for-large ">
            <ul><?php $printUserGroup($studentGroup); ?></ul>
        </div>
    <?php endforeach; ?>
</div>

