<?php $menuBarItems = $menuBarItems ?? array();
$unreadCount = $unreadCount ?? 0; ?>
<div class="show-for-large" data-sticky-container>
    <div class="top-bar" data-sticky data-options="marginTop:0;">
        <div class="top-bar-left">
            <div class="menu">
                <a class="logoLink" href="<?= base_url(); ?>">
                    <div class="clear button large title-text">StudyBuddies</div>
                </a>
            </div>
        </div>
        <div class="top-bar-right">
            <ul class="menu">
                <?php foreach ($menuBarItems as $item)
                    if ($item['enabled'] && !$item['mobileOnly']) {
                        $hidden = ($unreadCount === 0) ? 'is-hidden' : '';
                        $mBadge = ($item['content'] !== 'Messages') ? '' :
                            "<span class='badge alert message-badge {$hidden}'>{$unreadCount}</span>";
                        echo "<li><a href='{$item['href']}' class='{$item['class']}'>{$item['content']}{$mBadge}</a></li>";
                    } ?>
            </ul>
        </div>
    </div>
</div>
<div class="hide-for-large">
    <div class="top-bar">
        <div class="top-bar-left">
            <div class="menu">
                <a class="logoLink" href="<?= base_url(); ?>">
                    <div class="clear button large title-text">StudyBuddies</div>
                </a>
            </div>
        </div>
        <div class="top-bar-right">
            <a class="header-nav-trigger" data-toggle="header-nav">
                <!-- for screen readers -->
                Open navigation
                <!-- for icon -->
                <span class="hamburger"></span>
            </a>
        </div>
    </div>
    <nav id="header-nav" data-toggler=".open">
        <ul class="vertical menu">
            <?php foreach ($menuBarItems as $item)
                if ($item['enabled'] && !$item['desktopOnly'])
                    echo "<li><a href='{$item['href']}'>{$item['content']}</a></li>"; ?>
        </ul>
    </nav>
</div>