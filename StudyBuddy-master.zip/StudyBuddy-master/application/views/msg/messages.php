<?php use \Objects\Message;

/** @var Message[] $messages */
$messages = $messages ?? array();
$studentId = $studentId ?? null;

$messages = array_reverse($messages);

for ($i = 0; $i < count($messages); $i++) {
    $lastMessage = $messages[$i - 1] ?? null;
    $message = $messages[$i];
    $nextMessage = $messages[$i + 1] ?? null;

    $this->CI->load->view('msg/message', array(
        'lastMessage' => $lastMessage,
        'message' => $message,
        'nextMessage' => $nextMessage,
        'studentId' => $studentId));
}