<?php /** @var MY_Loader $this */

use \Objects\Chat_list;

/** @var Chat_list[] $chatLists */
$chatLists = $chatLists ?? array();
$chatSelected = $chatSelected ?? '';

foreach ($chatLists as $chatList)
    $this->CI->load->view('msg/chat-list', array(
        'chatList' => $chatList, 'chatSelected' => $chatSelected));