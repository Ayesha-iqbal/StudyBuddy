<?php /** @var MY_Loader $this */

use \Objects\Chat_list;
use \Objects\Message;

/** @var Chat_list[] $chatLists */
$chatLists = $chatLists ?? array();
$chatSelected = $chatSelected ?? '';
/** @var Message[] $messages */
$messages = $messages ?? array();
$studentId = $studentId ?? null; ?>
<div class="grid-x messenger">
    <div class="cell medium-3 messenger__scrollable">
        <ul class="vertical tabs messenger__chatLists">
            <?php $this->CI->load->view('msg/chat-lists', array(
                'chatLists' => $chatLists, 'chatSelected' => $chatSelected)); ?>
        </ul>
    </div>
    <div class="cell medium-9 messenger__borderLeft">
        <div class="messenger__mainPanel messenger__scrollable">
            <?php $this->CI->load->view('msg/messages', array(
                'messages' => $messages, 'studentId' => $studentId)); ?>
        </div>
        <div class="messenger__newMessageBar">
            <?= form_open_multipart('messenger/send_message'); ?>
            <?= "<input type='hidden' id='chatSelected' name='chatSelected' value='{$chatSelected}'>" ?>
            <label class="fas fa-file-upload messenger__uploadFile" title="Upload file">
                <input id="userFile" name="userFile" type="file" /></label><?php
            ?><textarea class="messenger__newMessage" rows="1" placeholder="Type a message..."
                        id="userMessage" name="userMessage"></textarea>
            <?= form_close(); ?>
        </div>
    </div>
</div>

