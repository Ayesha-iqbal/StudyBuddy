<?php /** @noinspection DuplicatedCode */

use \Objects\Chat_list;

/** @var Chat_list $chatList */
$chatList = $chatList ?? null;
$chatSelected = $chatSelected ?? '';

if (is_null($chatList)) return;

$gid = $chatList->to_group;
$sid = $chatList->to;

//region define $navTitle
$chatName = $chatList->group_name ?? $chatList->user_name;
if (!isset($chatList->id)) $chatName = "New message to {$chatName}";

$navTitle = "<div class='messenger__navTitle'>{$chatName}</div>";
//endregion
//region define $navMsgInner
if (isset($chatList->id)) {
    if ($chatList->media_type === '0') {
        // handle groups by using more conditions to determine if sender needs a label
        $sender = ($chatList->user_id === $chatList->from) ? 'You: ' : '';
        $message = "{$sender}{$chatList->message}";
    } else {
        $userNames = explode(' ', $chatList->user_name);
        $userName = reset($userNames);

        $mediaTypeMap = array(
            '1' => 'a photo',
            '2' => 'an audio message',
            '3' => 'a video',
            '4' => 'a PDF',
            '5' => 'a file');

        $sender = ($chatList->user_id === $chatList->from) ? 'You' : $userName;
        $aFile = $mediaTypeMap[$chatList->media_type] ?? 'a file';
        $message = "{$sender} sent {$aFile}.";
    }

    $navMsgInner = "<span class='messenger__navMsgInner'>{$message}</span>";
} else $navMsgInner = '';
//endregion
//region define $dot
$dot = "<span class='messenger__dot'>&middot;</span>";
//endregion
//region define $navDate
if (isset($chatList->id)) {
    /** @noinspection PhpUnhandledExceptionInspection */
    $nowTime = new DateTime('now', new DateTimeZone('America/Los_Angeles'));

    $chatLastTime = date('Y-m-d H:i:s', $chatList->timestamp);
    /** @noinspection PhpUnhandledExceptionInspection */
    $chatTime = new DateTime($chatLastTime, new DateTimeZone('UTC'));
    $chatTime->setTimezone(new DateTimeZone('America/Los_Angeles'));

    $sameDay = $nowTime->format('z') === $chatTime->format('z');
    $sameWeek = abs(+$nowTime->format('z') - +$chatTime->format('z')) < 7;
    $sameYear = $nowTime->format('Y') === $chatTime->format('Y');

    if ($sameDay) {
        $dateLabel = 'Today';
        $date = $chatTime->format('g:i A');
    } else if ($sameWeek) {
        $dateLabel = $chatTime->format('l');
        $date = $chatTime->format('D');
    } else if ($sameYear) {
        $dateLabel = $chatTime->format('F j');
        $date = $chatTime->format('M j');
    } else {
        $dateLabel = $chatTime->format('F j, Y');
        $date = $chatTime->format('n/j/y');
    }

    $navDate = "<span title='{$dateLabel}'>{$date}</span>";
} else $navDate = '';
//endregion
//region define $navMsg
if (isset($chatList->id)) {
    $navMsg = "<div class='messenger__navMsg'>{$navMsgInner}{$dot}{$navDate}</div>";
} else $navMsg = '';
//endregion
//region define $navLink
$chatUrl = (!is_null($gid)) ?
    base_url("messenger/g/{$gid}") :
    base_url("messenger/s/{$sid}");

$navLink = "<a href='{$chatUrl}'>{$navTitle}{$navMsg}</a>";
//endregion
//region define $navTab
$active = (!is_null($gid)) ?
    (("g/{$gid}" === $chatSelected) ? 'is-active' : '') :
    (("s/{$sid}" === $chatSelected) ? 'is-active' : '');

if (isset($chatList->id)) {
    $unread = ($chatList->status === '1' &&
        $chatList->from !== $chatList->user_id) ? 'unread' : '';
} else $unread = '';

$navTab = "<li class='tabs-title {$active} {$unread}'>{$navLink}</li>";
//endregion

echo $navTab;
