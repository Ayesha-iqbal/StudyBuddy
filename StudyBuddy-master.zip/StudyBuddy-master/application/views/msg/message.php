<?php /** @noinspection DuplicatedCode */

use \Objects\Message;

/** @var Message|null $lastMessage */
$lastMessage = $lastMessage ?? null;
/** @var Message $message */
$message = $message ?? null;
/** @var Message|null $nextMessage */
$nextMessage = $nextMessage ?? null;
$studentId = (string)$studentId ?? null;

if (is_null($message) || is_null($studentId)) return;

/** @noinspection PhpUnhandledExceptionInspection */
$nowTime = new DateTime('now', new DateTimeZone('America/Los_Angeles'));

if (!is_null($lastMessage)) {
    $lcLastTime = date('Y-m-d H:i:s', $lastMessage->timestamp);
    /** @noinspection PhpUnhandledExceptionInspection */
    $lcTime = new DateTime($lcLastTime, new DateTimeZone('UTC'));
    $lcTime->setTimezone(new DateTimeZone('America/Los_Angeles'));
}

$chatLastTime = date('Y-m-d H:i:s', $message->timestamp);
/** @noinspection PhpUnhandledExceptionInspection */
$chatTime = new DateTime($chatLastTime, new DateTimeZone('UTC'));
$chatTime->setTimezone(new DateTimeZone('America/Los_Angeles'));

$lcSameDay = !is_null($lastMessage) && $lcTime->format('z') === $chatTime->format('z');
$lcSameHour = $lcSameDay && abs(+$lcTime->format('G') - +$chatTime->format('G')) < 2;

$sameDay = $nowTime->format('z') === $chatTime->format('z');
$sameWeek = abs(+$nowTime->format('z') - +$chatTime->format('z')) < 7;

if ($sameDay) {
    $timeDate = $chatTime->format('g:i A');
    $msgDate = $chatTime->format('g:i A');
} else if ($sameWeek) {
    $timeDate = $chatTime->format('D g:i A');
    $msgDate = $chatTime->format('l g:i A');
} else {
    $timeDate = $chatTime->format('M j, Y, g:i A');
    $msgDate = $chatTime->format('F j, Y \a\t g:i A');
}

$icons = array(
    '1' => 'fas fa-file-image',
    '2' => 'fas fa-file-audio',
    '3' => 'fas fa-file-video',
    '4' => 'fas fa-file-pdf',
    '5' => 'fas fa-file');

$msgFrom = $message->from;
$float = ($message->from === $studentId) ? 'right' : 'left';

$msgId = "msg_{$message->id}";
$msgClass = "messenger__msg {$float}";

switch ($message->media_type) {
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
        $iconClass = $icons[$message->media_type];
        $msgContent = "<a href='{$message->media_url}' target='_blank' class='{$iconClass} messenger__mediaFile'></a><div class='messenger__mediaLabel'>{$message->media_name}</div>";
        break;
    case '0':
    default:
        $msgContent = htmlspecialchars($message->data);
        break;
}

$msg = "<div id='{$msgId}' data-from='{$msgFrom}' class='{$msgClass}' title='{$msgDate}'>{$msgContent}</div>";
$clearfixMsg = "<div class='clearfix'>{$msg}</div>";
$timeMsg = "<div class='messenger__time'>{$timeDate}</div>";

if (!$lcSameHour)
    echo $timeMsg;
echo $clearfixMsg;
