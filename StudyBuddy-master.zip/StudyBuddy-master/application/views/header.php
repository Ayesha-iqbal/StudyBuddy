<?php $title = $title ?? '';
$description = $description ?? '';
$assets = $assets ?? '';
$ogDefaultProps = array(
    'og:description' => $description,
    'og:site_name' => 'StudyBuddies',
    'og:title' => $title,
    'og:type' => 'website',
    'og:url' => current_url(),
);
$openGraphProps = $openGraphProps ?? $ogDefaultProps;
$openGraphProps = array_merge($ogDefaultProps, $openGraphProps); ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= $description; ?>">
    <?php foreach ($openGraphProps as $ogProp => $value): ?>
        <meta property="<?= $ogProp; ?>" content="<?= $value; ?>" />
    <?php endforeach; ?>
    <title><?= $title ?></title>
    <?php if (is_array($assets)) {
        foreach ($assets as $asset) echo $asset;
    } else echo $assets; ?>
</head>
