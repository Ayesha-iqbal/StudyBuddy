<?php

use \Objects\Course;
use \Objects\User;

/** @var Course[] $currentCourses */
$currentCourses = $currentCourses ?? array();
/** @var Course[] $previousCourses */
$previousCourses = $previousCourses ?? array();
/** @var User $student */
$student = $student ?? null;

$messageLink = base_url("messenger/s/{$student->id}"); ?>
<div class="grid-x grid-padding-x student">
    <div class="cell">
        <?= "<h1 class='h3 text-center margin-top-1'>{$student->name}</h1><hr>"; ?>
    </div>
    <div class="cell text-center">
        <?= "<a class='button student__button' href='{$messageLink}'>Message</a>&nbsp;"; ?>
    </div>
    <?= '<div class="cell"><hr></div>'; ?>
    <?php if (count($currentCourses)): ?>
        <div class="cell medium-offset-1 medium-10">
            <h2 class='h4 text-center'>Current Shared Classes</h2>
            <?php $this->CI->load->view('courses-grid', array('courses' => $currentCourses)); ?>
        </div>
    <?php endif;

    if (count($previousCourses)): ?>
        <div class="cell medium-offset-1 medium-10">
            <h2 class='h4 text-center'>Previous Shared Classes</h2>
            <?php $this->CI->load->view('courses-grid', array('courses' => $previousCourses)); ?>
        </div>
    <?php endif; ?>
</div>

