<?php $baseUrl = $baseUrl ?? base_url();
$showPhone = $showPhone ?? true;
$links = $links ??
    array(array(
        'title' => 'About',
        'links' => array(
            array('title' => 'About Us', 'link' => base_url('about-us')),
            array('title' => 'Blog', 'link' => base_url('blog')),
        ),
    ), array(
        'title' => 'Legal',
        'links' => array(
            array('title' => 'Privacy', 'link' => base_url('legal/privacy-policy')),
            array('title' => 'Terms', 'link' => base_url('legal/terms-of-use'))),
    ), array(
        'title' => 'Support',
        'links' => array(
            array('title' => 'Contact Us', 'link' => base_url('contact-us')),
            array('title' => 'FAQ', 'link' => base_url('faq'))),
    ));

$this->CI->load->view('headers/footer'); ?>
<footer>
    <div class="grid-x">
        <?php foreach ($links as $index => $link): ?>
            <div class="cell <?= ($index === 0) ? 'medium-offset-1 ' : ''; ?>medium-2">
                <div class="ll-title"><?= $link['title']; ?></div>
                <ul class="legal-links vertical menu simple">
                    <?php foreach ($link['links'] as $menuLink) {
                        echo "<li><a href='{$menuLink['link']}'>{$menuLink['title']}</a></li>";
                    } ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="grid-x">
        <div class="cell copyright medium-offset-9 medium-3">
            <?php $copyrightStartDate = 2019;
            $thisYear = getdate()['year'];
            $dateRange = ($copyrightStartDate != $thisYear) ?
                "$copyrightStartDate-$thisYear" : $copyrightStartDate; ?>
            &copy; <?= $dateRange; ?> StudyBuddies LLC
            <span class="hide-for-small-only">
                <?= (ENVIRONMENT === 'local') ? date('YmdHis') : ''; ?>
            </span>
        </div>
    </div>
</footer>