#!/bin/bash

if [ -e application/config/.env ]
then
  echo ".env already present"
else
  cp application/config/.env.example application/config/.env
  echo "copied .env"
fi

sudo npm install gulp-cli@2.0.1 -g
npm install
composer install

read -rp "Press any key to continue... " -n1 -s
