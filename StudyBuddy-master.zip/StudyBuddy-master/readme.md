## Requirements

+ Ensure [Node.js v8.12.0](https://nodejs.org/download/release/v8.12.0/) is installed on your system.
+ Ensure [PHP v7.1](https://www.php.net/downloads.php) or above is installed on your system. If not, download the 64-bit Thread Safe version.
  + In your PHP install directory, find the `php.ini` file and uncomment (remove the `;`) the lines `extension=php_curl.dll` and `extension=php_mysqli.dll`
+ Ensure [Composer](https://getcomposer.org/download/) is installed on your system.
  + Mac: download the [Latest Snapshot](https://getcomposer.org/composer.phar); assuming it is in your downloads folder, run `sudo cp ~/Downloads/composer.phar /usr/local/bin/composer` and then `sudo chmod +x /usr/local/bin/composer`
  + Windows: Download and run the [Setup](https://getcomposer.org/Composer-Setup.exe). You may need to add the installed file to your  Path environment variable (described below).
+ Ensure [Git](https://git-scm.com/downloads) is installed on your system.
+ Ensure [MySQL](https://dev.mysql.com/downloads/mysql/) and [MySQL Workbench](https://dev.mysql.com/downloads/workbench/) is installed on your system. If not download and install the community edition. 
  + When downloading, just click "No thanks, just start my download"
  + Mac install is insanely simple, follow below for Windows.
  + Install should probably be using Developer Default or Full if installing today.
  + Expect it to take upwards of 15 minutes to install.
  + Use the TCP/IP setting with port 8080; X Protocol probably doesn't matter. The firewall doesn't need to be open, as this will be local only.
  + For ease of use, start MySQL at system startup.
  + Either way, ensure that a DB exists running on `localhost:8080`, but it's easily configurable later.
  + The username could be `newuser` with the password `password`, but it's easily configurable later.
  + Add a new schema  named `studybuddy` in MySQL workbench. The charset should be `utf8` and collation should be `utf8_general_ci`

## Setup

+ Run `git clone https://github.com/mlemon573/StudyBuddy.git` wherever you want to put the project.
+ Run the `install.sh` script to install Gulp globally, initialize the `node_modules`, and `vendor` folders, and create the `.env` file in `application/config`. 
  + Mac: run the bash scripts from terminal using `bash install.sh`
  + Windows: double click the shell script, or run `bash install.sh`
+ Try to run `gulp --v`. If you cannot, you will need to add `%AppData%\npm` to your Path environment variable.
  +  Easiest way to do so is to search 'Environment Variables' and click 'Edit the system environment variables', and click 'Environment Variables' at the bottom.
  + Under 'System variables', find the `Path` and click edit. If npm is not present anywhere add it as written above. (`%AppData%\npm`)
  + Restart the shell for the Path changes to take effect
+ Run the `start.sh` script to start the server and transfer all files where they need to be. 
  + Mac: run the bash scripts from terminal using `bash start.sh`
  + Windows: double click the shell script, or run `bash start.sh`
  
## Troubleshooting
+ If you cannot see your .env file
  + Mac: run `defaults write com.apple.finder AppleShowAllFiles TRUE;killall Finder` to show all hidden files. If you no longer wish to see hidden files, run `defaults write com.apple.finder AppleShowAllFiles FALSE;killall Finder`
  + Windows: figure it out :)
+ If when running the watcher, your run into an error which say `mysqli::real_connect(): The server requested authentication method unknown to the client [caching_sha2_password]`
  + then execute this MySQL query to set your auth method to password. `ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';` (Replace root with your username, and password with your password).